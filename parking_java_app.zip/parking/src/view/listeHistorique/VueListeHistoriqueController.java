package view.listeHistorique;

import java.net.URL;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.ParkingException;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Historique;
import service.IServiceHistorique;
import service.Message;

public class VueListeHistoriqueController implements Initializable, Subscriber<Message<Historique>> {

	// Logger
	static Logger logger = LoggerFactory.getLogger(VueListeHistoriqueController.class);

	// couche de service
	private IServiceHistorique service;

	private Integer cpt;

	private Subscription subscription;
	@FXML
	private ResourceBundle bundle;

	@FXML
	private URL location;
	@FXML
	private TextField ztImmatr;

	@FXML
	private Button btValider;

	@FXML
	private TableView<Historique> tblHistorique;

	@FXML
	private TableColumn<Historique, LocalDateTime> col_ma;

	@FXML
	private TableColumn<Historique, LocalDateTime> col_Ms;

	@FXML
	private TableColumn<Historique, Long> col_Duree;

	@FXML
	private TableColumn<Historique, String> col_Place;

	@FXML
	private TextField ztCpt;

	@FXML
	private RadioButton rbSuppression;

	@FXML
	private Button btSupression;

	// Liste observable de la tableview
	private ObservableList<Historique> loHistorique;

	// Liste observable de la tableview
	//private ObservableList<Historique> loHistoriqueVoit;
	// le publisher d'évènement

	/**
	 * Permet de renvoyé la clé i18n adaptée à l'exception
	 * 
	 * @param e
	 * @return
	 */
	private String showErreur(ParkingException e) {
		if (e instanceof ParkingException)
			return bundle.getString("listeHis.unknown");
		return "ERROR X";
	}

	@FXML
	void valider(ActionEvent event) {
		btValider.setOnAction(e -> {
			try {
				// charge les historiques des voitures
				List<Historique> historiqueVoit = service.getHistoriqueVoit(ztImmatr.getText());
				// Transforme la liste en une liste observable
				loHistorique = FXCollections.observableList(historiqueVoit);
				// Donne la liste observable à la TableView
				tblHistorique.setItems(loHistorique);
				// Ajuste la zone de texte avec la taille
				ztCpt.setText(Integer.toString(historiqueVoit.size()));
				// InfoSortieVoiture i = service.sortieVoit(cbImmatr.getValue());
				// Affiche l'information dans la barre de status
				// String msg = i.getImmatr() + " " + bundle.getString("borneSortie.voitPlace")
				// + i.getPlace();
				// statusB.setInfoStatus(msg, TypeMessage.INFO);
			} catch (ParkingException exc) {
				logger.error("Impossible d'afficher  la liste des historiques ");
			}
		});

	}

	public void setUp(IServiceHistorique serviceHistorique) {
		// this.dao = dao;
		this.service = serviceHistorique;
		// this.stage = stage;
		initialiseDonnees();
		service.addObserver(this);

	}

	private void initialiseDonnees() {
		// charge les historiques des voitures
		List<Historique> historique = service.getListeHistorique();
		// Transforme la liste en une liste observable
		loHistorique = FXCollections.observableList(historique);
		// Donne la liste observable à la TableView
		tblHistorique.setItems(loHistorique);
		// Ajuste la zone de texte avec la taille
		 ztCpt.setText(Integer.toString(historique.size()));
	}

	@Override
	public void initialize(URL arg0, ResourceBundle bundle) {
		this.bundle = bundle;
		// spécifie la correspondance des colonnes avec les attributs de Historique
		col_ma.setCellValueFactory(new PropertyValueFactory<Historique, LocalDateTime>("momentA"));
		col_Ms.setCellValueFactory(new PropertyValueFactory<Historique, LocalDateTime>("momentS"));
		col_Duree.setCellValueFactory(new PropertyValueFactory<Historique, Long>("minutes"));
		col_Place.setCellValueFactory(new PropertyValueFactory<Historique, String>("place"));
		// Permet une sélection multiple
		/*
		 * tblHistorique.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		 * //active ou non la suppression
		 * btSupression.disableProperty().bind(rbSuppression.selectedProperty().not());
		 * // Evènement sur delete btSupression.setOnAction(a -> {
		 * ObservableList<Historique> liste =
		 * tblHistorique.getSelectionModel().getSelectedItems(); Alert alert = new
		 * Alert(AlertType.CONFIRMATION,
		 * bundle.getString("listeHis.confirmSuppression")); if
		 * (alert.showAndWait().get() == ButtonType.OK) liste.forEach(
		 * 
		 * e -> { try { service.delete(e.getId()); //désactive le bouton et radiobutton
		 * de sélection rbSuppression.setSelected(false); } catch (ParkingException e1)
		 * { logger.error("Impossible de supprimer la voiture "+e.getImmatr()); } }); ;
		 * });
		 */

	}

	/****************** GESTION PUBLICATION ********************/

	// Gestion des publications
	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscription = subscription;
		subscription.request(10);
		logger.info("Je suis un écouteur de historique");
	}

	// Reception des messages
	@Override
	public void onNext(Message<Historique> item) {
		logger.info(item.getOp() + " sur " + item.getElement());
		switch (item.getOp()) {
		case INSERT:
			Platform.runLater(() -> loHistorique.add(item.getElement()));
			break;
		case DELETE:
			Platform.runLater(() -> loHistorique.remove(item.getElement()));
			break;
		case UPDATE:
			/*
			 * { //recherche la voiture dans la liste cpt=-1; Optional<Personnel> op =
			 * loPersonnel.stream().filter((p)-> {cpt++;return
			 * p.getImmatr().equals(item.getElement().getImmatr());}).findFirst();
			 * if(op.isPresent()) Platform.runLater(()->loPersonnel.set(cpt,
			 * item.getElement())); }
			 */
			break;
		default:
			break;
		}
		// Platform.runLater(()->ztCpt.setText(Integer.toString(loPersonnel.size())));
		subscription.request(1);
	}

	@Override
	public void onError(Throwable throwable) {
		logger.error("erreur d'abonnement aux historiques de personne");

	}

	@Override
	public void onComplete() {
		logger.info(" écouteur de historique On Complete");
	}

	// Permet d'avoir la "Subscription pour se désabonner"
	public Subscription getSubscription() {
		return subscription;
	}

}
