package view.personnel;

import java.net.URL;
import java.util.ResourceBundle;

import dao.ParkingConstraintException;
import dao.ParkingException;
import dao.ParkingPKException;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Personnel;
import service.IServicePersonnel;
import view.statusBar.StatusBar;

public class VuePersonnelController implements Initializable {
	// permet de distinguer une vue d'ajout ou de modification
	private boolean modeAjout = true;

	// pseudo classe pour les erreurs
	private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");

	// couche de service
	private IServicePersonnel service;

	// personne à modifier ou à ajouter
	private Personnel personnel;

	// fenêtre principale de la vue
	private Stage stage;
	
	
    private ResourceBundle bundle;
    @FXML
    StatusBar statusbar;
    
	@FXML
	private Label lblTitre;
	@FXML
	private TextField ztImmatr;

	@FXML
	private TextField ztNom;

	@FXML
	private TextField ztPrenom;

	@FXML
	private TextField ztEmail;

	@FXML
	private Button btAjout;

	@FXML
	private Button btModif;

	@FXML
	void actionAjout(ActionEvent event) {

		Personnel p = new Personnel(ztImmatr.getText(), ztNom.getText(), ztPrenom.getText(), ztEmail.getText());

		try {
			// Désactive les pseudo-classes d'erreur
			desactivePseudoClass();
			// Insertion
			if (modeAjout)
				{
				service.insert(p);
				//statusbar.setInfoStatus("INSERT OK",TypeMessage.INFO);
				}
			else {
				service.update(p);
				personnel.setNom(ztNom.getText());
				personnel.setPrenom(ztPrenom.getText());
				personnel.setEmail(ztEmail.getText());
				//statusbar.setInfoStatus("Update OK",TypeMessage.INFO);
			}
			// reset les zones de texte
			videChamps();
			// ferme la fenêtre
			stage.hide();
		} catch (ParkingException pe) {
			//statusbar.setInfoStatus(pe.getMessage(),TypeMessage.ERROR);
			// active la pseudo-classe pour le champ en erreur
			if (pe instanceof ParkingPKException)
				ztImmatr.pseudoClassStateChanged(errorClass, true);
			else if (pe instanceof ParkingConstraintException)
				switch (((ParkingConstraintException) pe).getChamp()) {
				case "NOM_PER":
					ztNom.pseudoClassStateChanged(errorClass, true);
					break;
				case "PRENOM_PER":
					ztPrenom.pseudoClassStateChanged(errorClass, true);
					break;
				case "EMAIL_PER":
					ztEmail.pseudoClassStateChanged(errorClass, true);
					break;
				default:
					break;
				}
		}
	}
	
	@FXML
	private Button btAnnule;

	@FXML
	void actionAnnule(ActionEvent event) {
		// Récupère la fenêtre
		// ((Button) event.getSource()).getParent().getScene().getWindow().hide();
		desactivePseudoClass();
		videChamps();
		// ferme la fenêtre
		stage.hide();
	}

/**
 * Désactive les pseudo-classes pour supprimer le css des erreurs
 */
	private void desactivePseudoClass() {
		ztImmatr.pseudoClassStateChanged(errorClass, false);
		ztNom.pseudoClassStateChanged(errorClass, false);
		ztPrenom.pseudoClassStateChanged(errorClass, false);
		ztEmail.pseudoClassStateChanged(errorClass, false);
	}

	
	// initialisation du lien vers la couche de service
	public void setUp(IServicePersonnel servicePersonnel, Stage stage) {
		this.service = servicePersonnel;
		this.stage = stage;
	}

	public void ajouterPersonnel() {
		modeAjout = true;
		ztImmatr.setEditable(true);
		lblTitre.setText(bundle.getString("personnel.titre.ajout"));
		videChamps();
		btAjout.setVisible(true);
		btModif.setVisible(false);
		stage.showAndWait();
	}

	/**
	 * permet de préciser la personne à modifier
	 * 
	 * @param p
	 */
	public void modifierPersonnel(Personnel p) {
		if (p == null)
			ajouterPersonnel();

		modeAjout = false;
		this.personnel = p;
		ztImmatr.setEditable(false);
		btAjout.setVisible(false);
		btModif.setVisible(true);
		lblTitre.setText(bundle.getString("personnel.titre.modif"));

		// donne des valeurs au champ
		ztImmatr.setText(p.getImmatr());
		ztNom.setText(p.getNom());
		ztPrenom.setText(p.getPrenom());
		ztEmail.setText(p.getEmail());

		stage.showAndWait();
	}

	/**
	 * 
	 */
	private void videChamps() {
		ztImmatr.clear();
		ztNom.clear();
		ztPrenom.clear();
		ztEmail.clear();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle bundle) {
		this.bundle=bundle;
	}

}
