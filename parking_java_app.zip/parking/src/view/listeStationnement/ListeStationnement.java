package view.listeStationnement;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import model.Personnel;
import model.Place;
import model.Stationnement;
import service.IServiceArrivee;
import service.IServiceHistorique;
import service.Message;

public class ListeStationnement extends AnchorPane implements Initializable {
	// Logger
	static Logger logger = LoggerFactory.getLogger(ListeStationnement.class);

	// couche de service
	private IServiceArrivee service;

	private Integer cpt;

	private Subscription subscription;
	@FXML
	private ResourceBundle bundle;

	@FXML
	private URL location;

	@FXML
	private TableView<Stationnement> tblStationnement;

	@FXML
	private TableColumn<Stationnement, Personnel> col_immatr;

	@FXML
	private TableColumn<Stationnement, String> col_place;

	@FXML
	private TableColumn<Stationnement, LocalDateTime> col_ma;

	@FXML
	private TextField ztCpt;

	// Liste observable de la tableview
	private ObservableList<Stationnement> loStationnement;

	/**
	 * Constructeur qui charge la vue en appelant load()
	 */
	public ListeStationnement(IServiceArrivee serviceStationnement) {
		super();
		this.service = serviceStationnement;

		load();
		initialiseDonnees();
		//service.addObserver(this);
	}

	/*
	 * public void setUp(IServiceArrivee service) { this.service = service;
	 * initialiseDonnees(); //service.addObserver(this); }
	 */

	private void initialiseDonnees() {
		// charge les stationnements
		List<Stationnement> stationnement = service.getListeStationnemnt();
		// Transforme la liste en une liste observable
		loStationnement = FXCollections.observableList(stationnement);
		// Donne la liste observable à la TableView
		tblStationnement.setItems(loStationnement);
		// Ajuste la zone de texte avec la taille
		ztCpt.setText(Integer.toString(stationnement.size()));
	}

	public TableView<Stationnement> getTableView() {

		return tblStationnement;
	}

	public TextField getTextField() {
		return ztCpt;
	}

	public ObservableList<Stationnement> getListeObs() {
		return loStationnement;
	}

	/**
	 * Chargement de la vue fxml
	 */
	private void load() {
		try {
			// Crée un loader pour charger la vue FXML
			FXMLLoader loader = new FXMLLoader(getClass().getResource("VueListeStationnement.fxml"));
			// charge le bundle par rapport à la local par défaut
			bundle = ResourceBundle.getBundle("view.listeStationnement.bundle.VueListeStationnement");
			loader.setResources(bundle);
			// indique que sa racine est ce composant
			loader.setRoot(this);
			// indique que je suis son controller
			loader.setController(this);
			// Charge la vue à partir du Loader
			loader.load();
		} catch (IOException e) {
			// gestion de l’erreur du chargement
			Alert al1 = new Alert(AlertType.ERROR, e.getMessage());
			al1.showAndWait();
		}

	}

	@Override
	public void initialize(URL arg0, ResourceBundle bundle) {
		this.bundle = bundle;
		// spécifie la correspondance des colonnes avec les attributs
		col_immatr.setCellValueFactory(new PropertyValueFactory<Stationnement, Personnel>("personne"));
		col_place.setCellValueFactory(new PropertyValueFactory<Stationnement, String>("place"));
		col_ma.setCellValueFactory(new PropertyValueFactory<Stationnement, LocalDateTime>("momentA"));

	}

	/****************** GESTION PUBLICATION ********************/
/*
	// Gestion des publications
	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscription = subscription;
		subscription.request(10);
		logger.info("Je suis un écouteur de place");
	}

	// Reception des messages
	@Override
	public void onNext(Message<Place> item) {

		logger.info(item.getOp() + " sur " + item.getElement());
		switch (item.getOp()) {
		case INSERT:
			// Platform.runLater(()->loStationnement.add(item.getElement()));
			Platform.runLater(() -> {
				// charge les stationnements
				List<Stationnement> stationnement = service.getListeStationnemnt();
				// Transforme la liste en une liste observable
				loStationnement = FXCollections.observableList(stationnement);
				// Donne la liste observable à la TableView
				tblStationnement.setItems(loStationnement);
				// Ajuste la zone de texte avec la taille
				ztCpt.setText(Integer.toString(stationnement.size()));
			});
			break;
		case DELETE:
			// Platform.runLater(()->loStationnement.remove(item.getElement()));
			break;
		case UPDATE:
			/*
			 * { //recherche la voiture dans la liste cpt=-1; Optional<Stationnement> op =
			 * loStationnement.stream().filter((p)-> {cpt++;return
			 * p.getPersonne().getImmatr().equals(item.getElement().getPersonne().getImmatr(
			 * ));}).findFirst(); if(op.isPresent())
			 * Platform.runLater(()->loStationnement.set(cpt, item.getElement())); }
			 */
		/*	Platform.runLater(() -> {
				// charge les stationnements
				List<Stationnement> stationnement = service.getListeStationnemnt();
				// Transforme la liste en une liste observable
				loStationnement = FXCollections.observableList(stationnement);
				// Donne la liste observable à la TableView
				tblStationnement.setItems(loStationnement);
				// Ajuste la zone de texte avec la taille
				ztCpt.setText(Integer.toString(stationnement.size()));
			});
			break;
		default:
			break;
		}

		Platform.runLater(() -> ztCpt.setText(Integer.toString(loStationnement.size())));
		subscription.request(1);
	}

	@Override
	public void onError(Throwable throwable) {
		logger.error("erreur d'abonnement aux stationnements de personne");

	}

	@Override
	public void onComplete() {
		logger.info(" écouteur de stationnement On Complete");
	}

	// Permet d'avoir la "Subscription pour se désabonner"
	public Subscription getSubscription() {
		return subscription;
	}*/
}
