package view.place;

import java.net.URL;
import java.util.ResourceBundle;

import dao.ParkingConstraintException;
import dao.ParkingException;
import dao.ParkingPKException;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Place;
import service.IservicePlace;

public class VuePlaceController implements Initializable {

	// permet de distinguer une vue d'ajout ou de modification
	private boolean modeAjout = true;

	// pseudo classe pour les erreurs
	private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");

	// couche de service
	private IservicePlace service;

	// personne à modifier ou à ajouter
	private Place place;

	// fenêtre principale de la vue
	private Stage stage;

	@FXML
	private ResourceBundle bundle;

	@FXML
	private URL location;
	@FXML
	private Label lblTitre;
	@FXML
	private TextField ztCode;

	@FXML
	private TextField ztTaille;

	@FXML
	private Button btAjout;
	@FXML
	private Button btModif;
	@FXML
	private Button btCancel;

	@FXML
	void actionAjout(ActionEvent event) {
		Place p = new Place(ztCode.getText(), Integer.parseInt(ztTaille.getText()));

		try {
			// Désactive les pseudo-classes d'erreur
			desactivePseudoClass();
			// Insertion
			if (modeAjout) {
				service.insert(p);
				// statusbar.setInfoStatus("INSERT OK",TypeMessage.INFO);
			} else {
				service.update(p);
				place.setCode(ztCode.getText());
				place.setTaille(Integer.parseInt(ztTaille.getText()));
				// personnel.setEmail(ztEmail.getText());
				// statusbar.setInfoStatus("Update OK",TypeMessage.INFO);
			}
			// reset les zones de texte
			videChamps();
			// ferme la fenêtre
			stage.hide();
		} catch (ParkingException pe) {
			// statusbar.setInfoStatus(pe.getMessage(),TypeMessage.ERROR);
			// active la pseudo-classe pour le champ en erreur
			if (pe instanceof ParkingPKException)
				ztCode.pseudoClassStateChanged(errorClass, true);
			else if (pe instanceof ParkingConstraintException)
				switch (((ParkingConstraintException) pe).getChamp()) {
				case "CODE_PLA":
					ztCode.pseudoClassStateChanged(errorClass, true);
					break;
				case "TAILLE_PLA":
					ztTaille.pseudoClassStateChanged(errorClass, true);
					break;
				default:
					break;
				}
		}

	}

	@FXML
	void annuler(ActionEvent event) {

		// Récupère la fenêtre
		// ((Button) event.getSource()).getParent().getScene().getWindow().hide();
		desactivePseudoClass();
		videChamps();
		// ferme la fenêtre
		stage.hide();
	}
	
	/**
	 * Désactive les pseudo-classes pour supprimer le css des erreurs
	 */
		private void desactivePseudoClass() {
			ztCode.pseudoClassStateChanged(errorClass, false);
			ztTaille.pseudoClassStateChanged(errorClass, false);
			
		}

		
		// initialisation du lien vers la couche de service
		public void setUp(IservicePlace servicePlace, Stage stage) {
			this.service = servicePlace;
			this.stage = stage;
		}
		
		public void ajouterPlace() {
			modeAjout = true;
			ztCode.setEditable(true);
			ztTaille.setEditable(true);
			lblTitre.setText(bundle.getString("place.titre.ajout"));
			videChamps();
			btAjout.setVisible(true);
			btModif.setVisible(false);
			stage.showAndWait();
		}

		/**
		 * permet de préciser la personne à modifier
		 * 
		 * @param p
		 */
		public void modifierPlace(Place p) {
			if (p == null)
				ajouterPlace();

			modeAjout = false;
			this.place = p;
			ztCode.setEditable(false);
			ztTaille.setEditable(true);
			btAjout.setVisible(false);
			btModif.setVisible(true);
			lblTitre.setText(bundle.getString("place.titre.modif"));

			// donne des valeurs au champ
			ztCode.setText(p.getCode());
			ztTaille.setText(Integer. toString(p.getTaille()));

			stage.showAndWait();
		}

		/**
		 * 
		 */
		private void videChamps() {
			ztCode.clear();
			ztTaille.clear();
			
		}


	@Override
	public void initialize(URL arg0, ResourceBundle bundle) {
		this.bundle = bundle;
	}

}
