package view.statusBar;

import java.io.IOException;
import java.util.ResourceBundle;

import javafx.beans.property.StringProperty;
import javafx.css.PseudoClass;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class StatusBar extends AnchorPane {
	// Type des messages
	public enum TypeMessage {
		NONE, INFO, ERROR
	};
	
	//Status actuel
	TypeMessage status = TypeMessage.INFO;

	// Pseudo classe pour avec un style css adapté en mode d'erreur :error
	private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");

	@FXML
	private ResourceBundle bundle;

	@FXML
	private Label lblStatus;

	@FXML
	private TextField ztStatus;

	/**
	 * Constructeur qui charge la vue en appelant load()
	 */
	public StatusBar() {
		super();
		load();
	}
/**
 * Chargement de la vue fxml 
 */
	private void load() {
		try {
			// Crée un loader pour charger la vue FXML
			FXMLLoader loader = new FXMLLoader(getClass().getResource("StatusBar.fxml"));
			// charge le bundle par rapport à la local par défaut
			bundle = ResourceBundle.getBundle("view.statusBar.bundles.vueStatus");
			loader.setResources(bundle);
			// indique que sa racine est ce composant
			loader.setRoot(this);
			// indique que je suis son controller
			loader.setController(this);
			// Charge la vue à partir du Loader
			loader.load();
		} catch (IOException e) {
			// gestion de l’erreur du chargement
			Alert al1 = new Alert(AlertType.ERROR, e.getMessage());
			al1.showAndWait();
		}

	}

	/**
	 * Obtention du status actuel
	 * @return status actuel
	 */
	public TypeMessage getEtatStatus() {
		return status;
	}

	/**
	 * Efface les messages
	 */
	public void clearStatusBar() {
		// indique un mode sans erreur
		setInfoStatus("", TypeMessage.NONE);

	}

	// Initialise les zones de textes avec l'article sélectionné
	public void setInfoStatus(String message, TypeMessage type) {
		status = type;
		
		switch (type) {
		case NONE:
			ztStatus.clear();
			break;
		case INFO:
		case ERROR:
			ztStatus.setText(message);
		}
		//ajuste les pseudo-classes
		lblStatus.pseudoClassStateChanged(errorClass, status == TypeMessage.ERROR);
		ztStatus.pseudoClassStateChanged(errorClass, status == TypeMessage.ERROR);
	}
	
	/*
	 * Méthodes pour en faire un bean pour la propriété Text
	 */
	public String getText() {
        return textProperty().get();
    }

    public void setText(String value) {
        textProperty().set(value);
    }

    public StringProperty textProperty() {
        return ztStatus.textProperty();
    }
	/**
	 * initialise les composants lors du chargement
	 */
	@FXML
	void initialize() {

	}
}
