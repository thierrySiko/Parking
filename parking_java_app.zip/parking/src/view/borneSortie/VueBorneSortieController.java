package view.borneSortie;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.ParkingEmptyException;
import dao.ParkingException;
import dao.ParkingPKException;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import model.InfoSortieVoiture;
import model.Place;
import service.IServiceArrivee;
//import service.IServiceSortie;
import service.Message;
import view.statusBar.StatusBar;
import view.statusBar.StatusBar.TypeMessage;

public class VueBorneSortieController implements Initializable, Subscriber<Message<Place>> {
	// Logger
	static Logger logger = LoggerFactory.getLogger(VueBorneSortieController.class);

	// private IPlaceDAO dao;
	// couche de service
	private IServiceArrivee service;
	// personne à retirer du parking
	// private Personnel personnel;

	// fenêtre principale de la vue
	// private Stage stage;
	// private ResourceBundle bundle;
	private Subscription subscription;
	@FXML
	private ResourceBundle bundle;

	@FXML
	private URL location;
	@FXML
	private ComboBox<String> cbImmatr;
	@FXML
	private Button btOut;

	@FXML
	private StatusBar statusB;

	// Liste observable de la tableview
	private ObservableList<String> loListImmatr;

	/**
	 * Permet de renvoyé la clé i18n adaptée à l'exception
	 * 
	 * @param e
	 * @return
	 */
	private String showErreur(ParkingException e) {
		if (e instanceof ParkingEmptyException)
			return bundle.getString("borneSortie.vide");
		// if (e instanceof ParkingPlaceBusyException)
		// return ((ParkingPlaceBusyException)e).getPlace() +" "+
		// bundle.getString("PlaceBusy") ;
		if (e instanceof ParkingPKException)
			return bundle.getString("borneSortie.alreadyOut");
		if (e instanceof ParkingException)
			return bundle.getString("borneSortie.unknown");
		return "ERROR X";
	}

	// ObservableList<String> list = service.getListeStationnemntImmatr();
	// cbImmatr.setItems(list);
	@FXML
	void valider(ActionEvent event) {
		// cbImmatr.setItems(list);
		btOut.setOnAction(e -> {
			try {
				InfoSortieVoiture i = service.sortieVoit(cbImmatr.getValue());
				// Affiche l'information dans la barre de status
				String msg = i.getImmatr() + " " + bundle.getString("borneSortie.voitPlace") + i.getPlace();
				statusB.setInfoStatus(msg, TypeMessage.INFO);
			} catch (ParkingException exc) {
				statusB.setInfoStatus(showErreur(exc), TypeMessage.INFO);
			}
		});

	}

	public void setUp(IServiceArrivee serviceSortie) {
		// this.dao = dao;
		this.service = serviceSortie;
		// this.stage = stage;
		initialiseDonnees();
		service.addObserver(this);

	}

	private void initialiseDonnees() {
		// charge les voitures en stationnement de la BD
		List<String> listImmatr = service.getListeStationnemntImmatr();
		// Transforme la liste en une liste observable
		loListImmatr = FXCollections.observableList(listImmatr);
		// Donne la liste observable à la TableView
		cbImmatr.setItems(loListImmatr);
		// Ajuste la zone de texte avec la taille
		// ztCpt.setText(Integer.toString(personnel.size()));
	}

	@Override
	public void initialize(URL arg0, ResourceBundle bundle) {
		this.bundle = bundle;

	}

	/****************** GESTION PUBLICATION ********************/

	// Gestion des publications
	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscription = subscription;
		subscription.request(10);
		logger.info("Je suis un écouteur de Stationnement Borne Out");
	}

	// Reception des messages
	@Override
	public void onNext(Message<Place> item) {
		logger.info(item.getOp() + " sur " + item.getElement());
		Place p = item.getElement();
		// Button bt= boutons.get(p.getCode());

		switch (item.getOp()) {
		case INSERT:

			break;
		case DELETE:

			break;
		case UPDATE:
			// if (bt!=null)
			// Platform.runLater(()->bt.pseudoClassStateChanged(freeClass, !p.getLibre()));
			Platform.runLater(() -> {
				// charge les voitures en stationnement de la BD
				List<String> listImmatr = service.getListeStationnemntImmatr();
				// Transforme la liste en une liste observable
				loListImmatr = FXCollections.observableList(listImmatr);
				// Donne la liste observable à la TableView
				cbImmatr.setItems(loListImmatr);
			});

			// Ajuste la zone de texte avec la taille
			// ztCpt.setText(Integer.toString(personnel.size()));
		default:
			break;
		}
		subscription.request(1);
	}

	@Override
	public void onError(Throwable throwable) {
		logger.error("erreur d'abonnement à la borne de sortie");

	}

	@Override
	public void onComplete() {
		logger.info(" écouteur de BorneOut On Complete");
	}

	// Permet d'avoir la "Subscription pour se désabonner"
	public Subscription getSubscription() {
		return subscription;
	}

}
