package database.connexion;

import java.util.Properties;

import database.uri.Databases;

public class ConnexionH2MemTest implements IConnexionInfos {

	@Override
	public Properties getProperties() {
		Properties prop = new Properties();
		prop.put("url", Databases.H2.buildMemURL("test"));
		prop.put("user", "sa");
		prop.put("password", "");
		return prop;
	}

}
