package service;

import java.util.List;
import java.util.concurrent.Flow.Subscriber;

import dao.ParkingException;
import model.Historique;

public interface IServiceHistorique {
	
	List<Historique> getListeHistorique();

	List<Historique> getHistoriqueVoit(String immatr) throws ParkingException;
	/**
	 * Permet de s'abonner aux publications sur le stationnement
	 * 
	 * @param obs celui qui veut s'abonner
	 */
	//void delete(IdHistorique id) throws ParkingException;
		
	public void addObserver(Subscriber<Message<Historique>> obs);
	//public void addObserverS(Subscriber<Message<Stationnement>> obs);

}
