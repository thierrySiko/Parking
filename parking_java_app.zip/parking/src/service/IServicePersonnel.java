package service;

import java.util.List;

import dao.ParkingException;
import model.Personnel;
import java.util.Optional;
import java.util.concurrent.Flow.Subscriber;

public interface IServicePersonnel {
	/**
	 * Liste des voitures du personnel
	 * 
	 * @return
	 */
	List<Personnel> getListePersonne();

	/**
	 * Ajouter une voiture pour une personne du personnel
	 * 
	 * @param p
	 * @throws ParkingException
	 */
	void insert(Personnel p) throws ParkingException;

	/**
	 * Supprimer une voiture pour une personne du personnel
	 * 
	 * @param p
	 * @throws ParkingException
	 */
	void delete(String p) throws ParkingException;

	/**
	 * Retourne le nombre de voitures du personnel
	 * 
	 * @return
	 */
	public int count();

	/**
	 * Maj d'une voiture du personnel
	 * 
	 * @param p
	 * @throws ParkingException
	 */
	void update(Personnel p) throws ParkingException;

	/**
	 * Obtenir une voiture à partir de sa plaque
	 * 
	 * @param immatr
	 * @return
	 */
	Optional<Personnel> getFromID(String immatr);

	/**
	 * Permet de s'abonner aux publications sur le personnel
	 * 
	 * @param obs celui qui veut s'abonner
	 */
	public void addObserver(Subscriber<Message<Personnel>> obs);
}
