package service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.SubmissionPublisher;

import dao.IHistoriqueDAO;
import dao.ParkingException;
import model.Historique;

public class ServiceHistorique implements IServiceHistorique {

	private IHistoriqueDAO daoHistorique;

	// permet de publier des messages
	private SubmissionPublisher<Message<Historique>> publisherHistorique = new SubmissionPublisher<>();

	/**
	 * Constructeur
	 * 
	 * @param daoHistorique
	 */
	public ServiceHistorique(IHistoriqueDAO daoHistorique) {
		this.daoHistorique = daoHistorique;

	}

	@Override
	public List<Historique> getListeHistorique() {
		return daoHistorique.getListe("");
	}
	/*
	@Override
	public void delete(IdHistorique id) throws ParkingException {
		// recherche la personne
		Optional<Historique> p = daoHistorique.getFromID(id);
		// si elle existe on la supprime
		if (p.isEmpty())
			throw new ParkingPKException("Code INEXISTANT", 0, "IMMATR");
		try {
			daoPersonne.delete(p.get());
			//publie l'évènement
			publisher.submit(new Message<Personnel>(TypeOperation.DELETE, p.get()));
		} catch (Exception e) {// dipatch l'exception en ParkingException
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			throw new ParkingException("ERREUR Lors de la suppression", 0);
		}

	}*/

	public List<Historique> getHistoriqueVoit(String immatr) throws ParkingException {
		// IStationnementDAO dao = factory.getStationnementDAO();
		List<Historique> liste = new ArrayList<>();

		try {
			liste = daoHistorique.getHistoriqueVoiture(immatr);

		} catch (Exception e) {
			// recherche la place
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			else if (!(e instanceof ParkingException))
				throw new ParkingException("Erreur Inconnue", 0);
		}

		return liste;
	}

	@Override
	public void addObserver(Subscriber<Message<Historique>> obs) {
		this.publisherHistorique.subscribe(obs);
	}

}
