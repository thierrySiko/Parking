package service;

import java.util.List;
import java.util.concurrent.Flow.Subscriber;

import dao.ParkingException;
import model.InfoSortieVoiture;
import model.Place;
import model.Stationnement;

public interface IServiceArrivee {

	List<Place> getListePlace();

	Stationnement arriveeVoit(String plaque, String place) throws ParkingException;
	/**
	 * Permet de s'abonner aux publications sur le stationnement
	 * 
	 * @param obs celui qui veut s'abonner
	 */
	
	//List<Place> getListePlace();
		List<String> getListeStationnemntImmatr();
		
		List<Stationnement> getListeStationnemnt();

		InfoSortieVoiture sortieVoit(String plaque) throws ParkingException;
		
	public void addObserver(Subscriber<Message<Place>> obs);
	public void addObserverS(Subscriber<Message<Stationnement>> obs);
  
}
