package service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Flow.Subscriber;

import dao.ParkingException;
import model.Place;

public interface IservicePlace {
	
	/**
	 * Liste des places
	 * 
	 * @return
	 */
	List<Place> getListePlace();

	/**
	 * Ajouter une place 
	 * 
	 * @param p
	 * @throws ParkingException
	 */
	void insert(Place p) throws ParkingException;

	/**
	 * Supprimer place
	 * 
	 * @param p
	 * @throws ParkingException
	 */
	void delete(String p) throws ParkingException;

	/**
	 * Retourne le nombre de places
	 * 
	 * @return
	 */
	public int count();

	/**
	 * Maj d'une place
	 * 
	 * @param p
	 * @throws ParkingException
	 */
	void update(Place p) throws ParkingException;

	/**
	 * Obtenir une place à partir de son code
	 * 
	 * @param immatr
	 * @return
	 */
	Optional<Place> getFromID(String code);

	/**
	 * Permet de s'abonner aux publications sur la place
	 * 
	 * @param obs celui qui veut s'abonner
	 */
	public void addObserver(Subscriber<Message<Place>> obs);

}
