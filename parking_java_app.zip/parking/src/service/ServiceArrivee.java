package service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.SubmissionPublisher;

//import dao.DAOFactory;

import dao.IPlaceDAO;
import dao.IStationnementDAO;
import dao.ParkingException;
import model.InfoSortieVoiture;
import model.Place;
import model.Stationnement;

public class ServiceArrivee implements IServiceArrivee {

	// private DAOFactory factory;
	// dao
	private IPlaceDAO daoPlace;
	private IStationnementDAO daoStationnement;

	// permet de publier des messages
	private SubmissionPublisher<Message<Place>> publisherPlace = new SubmissionPublisher<>();
	private SubmissionPublisher<Message<Stationnement>> publisherSta = new SubmissionPublisher<>();

	/**
	 * Constructeur
	 * 
	 * @param daoPlace
	 */
	public ServiceArrivee(IPlaceDAO daoPlace, IStationnementDAO daoStationnement) {
		this.daoPlace = daoPlace;
		this.daoStationnement = daoStationnement;
	}
	/*
	 * public ServiceArrivee(DAOFactory factory) { this.factory=factory; }
	 */
	

	@Override
	public List<Place> getListePlace() {
		return daoPlace.getListe("");
	}

	/*
	 * @Override public List<Place> getListePlace() { IPlaceDAO dao =
	 * factory.getPlaceDAO(); List<Place> l = dao.getListe(""); return l; }
	 */

	@Override
	public Stationnement arriveeVoit(String plaque, String place) throws ParkingException {
		// IStationnementDAO dao = factory.getStationnementDAO();
		Stationnement s = null;
		Place p = null;
		try {
			if (place == null) {
				s = daoStationnement.arriveeVoiture(plaque);
				Optional<Place> op = daoPlace.getFromID(s.getPlace());
				p = op.get();
			} else {
				s = daoStationnement.arriveeVoiture(plaque, place);
				p = daoPlace.getFromID(place).get();
			}
			publisherPlace.submit(new Message<Place>(TypeOperation.UPDATE, p));
		} catch (Exception e) {
			// recherche la place
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			else if (!(e instanceof ParkingException))
				throw new ParkingException("Erreur Inconnue", 0);
		}
		// Récupère la place

		// Vérifie la disponibilité de la place
		/*
		 * if (!daoPlace.getFromID(place).get().getLibre()) throw new
		 * ParkingPlaceBusyException("Place Occupée", 0, "ID Place");
		 */
		// p.setLibre(false);
		
		//publisherSta.submit(new Message<Stationnement>(TypeOperation.UPDATE, s));
		return s;
	}

	// Optional<Place> op = daoPlace.getFromID(place);
	// Place p=op.get();

	/*
	 * catch (Exception e) {
	 * 
	 * if (e instanceof ParkingException) throw (ParkingException) e; else throw new
	 * ParkingException("Erreur Inconnue", 0); }
	 */
	@Override
	public List<String> getListeStationnemntImmatr() {
		return daoStationnement.getListeImmatr("");
	}
	@Override
	public List<Stationnement> getListeStationnemnt() {
		return daoStationnement.getListe("");
	}
	@Override
	public InfoSortieVoiture sortieVoit(String plaque) throws ParkingException {
		// IStationnementDAO dao = factory.getStationnementDAO();
		InfoSortieVoiture i = null;
		Place p = null;
		try {
			i=daoStationnement.sortieVoiture(plaque);
			Optional<Place>op = daoPlace.getFromID(i.getPlace());
			p=op.get();
			publisherPlace.submit(new Message<Place>(TypeOperation.UPDATE, p));
		} catch (Exception e) {
			// recherche la place
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			else if (!(e instanceof ParkingException))
				throw new ParkingException("Erreur Inconnue", 0);
		}
		// Récupère la place

		// Vérifie la disponibilité de la place
		/*
		 * if (!daoPlace.getFromID(place).get().getLibre()) throw new
		 * ParkingPlaceBusyException("Place Occupée", 0, "ID Place");
		 */
		// p.setLibre(false);
		
		//publisherSta.submit(new Message<Stationnement>(TypeOperation.DELETE, s));
		return i;
	}
	@Override
	public void addObserver(Subscriber<Message<Place>> obs) {
		this.publisherPlace.subscribe(obs);
	}
	@Override
	public void addObserverS(Subscriber<Message<Stationnement>> obs) {
		this.publisherSta.subscribe(obs);
	}

}
