package service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.SubmissionPublisher;

import dao.IPlaceDAO;
import dao.ParkingException;
import dao.ParkingPKException;
import model.Place;

public class ServicePlace implements IservicePlace {
	
	// dao
		private IPlaceDAO daoPlace;
		
		// permet de publier des messages
		private SubmissionPublisher<Message<Place>> publisher = new SubmissionPublisher<>();


		/**
		 * Constructeur
		 * 
		 * @param daoPlacee
		 */
		public ServicePlace(IPlaceDAO daoPlace) {
			this.daoPlace = daoPlace;
		}

		@Override
		public List<Place> getListePlace() {
			return daoPlace.getListe("");
		}

		@Override
		public void insert(Place p) throws ParkingException {
			// ajoute une place
			try {
				p = daoPlace.insert(p);
				//publie l'évènement
				publisher.submit(new Message<Place>(TypeOperation.INSERT, p));
			} catch (Exception e) {
				if (e instanceof ParkingException)
					throw (ParkingException) e;
				else
					throw new ParkingException("Erreur inconnue", 0);
			}

		}

		@Override
		public void delete(String code) throws ParkingException {
			// recherche la personne
			Optional<Place> p = daoPlace.getFromID(code);
			// si elle existe on la supprime
			if (p.isEmpty())
				throw new ParkingPKException("Code INEXISTANT", 0, "IMMATR");
			try {
				daoPlace.delete(p.get());
				//publie l'évènement
				publisher.submit(new Message<Place>(TypeOperation.DELETE, p.get()));
			} catch (Exception e) {// dipatch l'exception en ParkingException
				if (e instanceof ParkingException)
					throw (ParkingException) e;
				throw new ParkingException("ERREUR Lors de la suppression", 0);
			}

		}

		@Override
		public int count() {
			return daoPlace.count();
		}

		@Override
		public void update(Place p) throws ParkingException {
			// modifie une place
			try {
				daoPlace.update(p);
				//publie l'évènement
				publisher.submit(new Message<Place>(TypeOperation.UPDATE, p));
			} catch (Exception e) {
				if (e instanceof ParkingException)
					throw (ParkingException) e;
				else
					throw new ParkingException("Erreur inconnue", 0);
			}

		}

		/**
		 * Retourne une place en fct de son id
		 */
		@Override
		public Optional<Place> getFromID(String code) {
			return daoPlace.getFromID(code);
		}
		
		/**
		 * Permet de s'abonner aux publications sur la place
		 * @param obs celui qui veut s'abonner
		 */
		public void addObserver(Subscriber<Message<Place>> obs) {
			//enregistre un écouteur (abonné)
			publisher.subscribe(obs);
			
		}

}
