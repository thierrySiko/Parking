package service;

/**
 * Message envoyé aux écouteurs 
 * 
 * @author Didier
 *
 */
public class Message<T> {
	private final TypeOperation op;
	private final T element;

	public Message(TypeOperation op, T element) {
		this.op = op;
		this.element = element;
	}

	public TypeOperation getOp() {
		return op;
	}

	public T getElement() {
		return element;
	}	
}
