package service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.Flow.Subscriber;

import dao.IPersonnelDAO;
import dao.ParkingException;
import dao.ParkingPKException;
import model.Personnel;

public class ServicePersonnel implements IServicePersonnel {
	// dao
	private IPersonnelDAO daoPersonne;
	
	// permet de publier des messages
	private SubmissionPublisher<Message<Personnel>> publisher = new SubmissionPublisher<>();


	/**
	 * Constructeur
	 * 
	 * @param daoPersonne
	 */
	public ServicePersonnel(IPersonnelDAO daoPersonne) {
		this.daoPersonne = daoPersonne;
	}

	@Override
	public List<Personnel> getListePersonne() {
		return daoPersonne.getListe("");
	}

	@Override
	public void insert(Personnel p) throws ParkingException {
		// ajoute une personne
		try {
			p = daoPersonne.insert(p);
			//publie l'évènement
			publisher.submit(new Message<Personnel>(TypeOperation.INSERT, p));
		} catch (Exception e) {
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			else
				throw new ParkingException("Erreur inconnue", 0);
		}

	}

	@Override
	public void delete(String code) throws ParkingException {
		// recherche la personne
		Optional<Personnel> p = daoPersonne.getFromID(code);
		// si elle existe on la supprime
		if (p.isEmpty())
			throw new ParkingPKException("Code INEXISTANT", 0, "IMMATR");
		try {
			daoPersonne.delete(p.get());
			//publie l'évènement
			publisher.submit(new Message<Personnel>(TypeOperation.DELETE, p.get()));
		} catch (Exception e) {// dipatch l'exception en ParkingException
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			throw new ParkingException("ERREUR Lors de la suppression", 0);
		}

	}

	@Override
	public int count() {
		return daoPersonne.count();
	}

	@Override
	public void update(Personnel p) throws ParkingException {
		// modifie une personne
		try {
			daoPersonne.update(p);
			//publie l'évènement
			publisher.submit(new Message<Personnel>(TypeOperation.UPDATE, p));
		} catch (Exception e) {
			if (e instanceof ParkingException)
				throw (ParkingException) e;
			else
				throw new ParkingException("Erreur inconnue", 0);
		}

	}

	/**
	 * Retourne une personne en fct de son id
	 */
	@Override
	public Optional<Personnel> getFromID(String immatr) {
		return daoPersonne.getFromID(immatr);
	}
	
	/**
	 * Permet de s'abonner aux publications sur le personnel
	 * @param obs celui qui veut s'abonner
	 */
	public void addObserver(Subscriber<Message<Personnel>> obs) {
		//enregistre un écouteur (abonné)
		publisher.subscribe(obs);
		
	}

}
