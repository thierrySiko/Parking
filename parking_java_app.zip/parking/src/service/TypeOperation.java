package service;

public enum TypeOperation {
	INSERT,UPDATE,DELETE
}
