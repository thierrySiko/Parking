package dao;

import model.Place;

public interface IPlaceDAO extends IDAO<Place, String> {

}
