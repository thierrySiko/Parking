package dao;

import model.Personnel;

public interface IPersonnelDAO extends IDAO<Personnel, String> {

}
