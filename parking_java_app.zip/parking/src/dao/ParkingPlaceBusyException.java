package dao;

public class ParkingPlaceBusyException extends ParkingException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String place;

	public ParkingPlaceBusyException(String msg, int code, String place) {
		super(msg, code);
		this.place = place;
	}

	public String getPlace() {
		return place;
	}

}
