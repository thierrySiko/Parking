package dao;

import java.sql.CallableStatement;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
//import java.time.ZoneId;
//import java.time.LocalDateTime;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import model.Historique;
import model.IdHistorique;




public abstract class SQLHistoriqueDAO implements IHistoriqueDAO {
	//private static final String SQL_FROM_ID = "Select FKPERSONNE_HIS,MOMENTA_HIS,FKPLACE_HIS,MOMENTS_HIS from THISTORIQUE where FKPERSONNE_HIS=? and FKPLACE_HIS=?";
	private static final String SQL_LISTE = "Select trim(FKPERSONNE_HIS),MOMENTA_HIS,FKPLACE_HIS,MOMENTS_HIS from THISTORIQUE";
	public static final String SQL_LISTE_HVOIT = "?,?,?,?=CALL HISTORIQUE(?)"; 
	public static final String SQL_LISTE_HJOUR= "SELECT FKPERSONNE_HIS,MOMENTA_HIS,FKPLACE_HIS,MOMENTS_HIS  FROM THISTORIQUE where (cast(cast(MOMENTA_HIS as date) as varchar(24)))=? order by MOMENTA_HIS asc";
	//private static final String SQL_DELETE = "Delete from THISTORIQUE WHERE FKPERSONNE_HIS=? AND FKPLACE_HIS=?";
	//SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	// Logger
	private static final Logger logger = LoggerFactory.getLogger(SQLHistoriqueDAO.class);

	// La factory pour avoir la connexion
	private final SQLDAOFactory factory;

	/**
	 * Construction pour avoir l'accès à la factory et ainsi obtenir la connexion
	 * 
	 * @param factory
	 */
	public SQLHistoriqueDAO(SQLDAOFactory factory) {
		this.factory = factory;
	}

	/**
	 * A partir de son id renvoie un Optional de Historique
	 */
	/*public Optional<Historique> getFromID(IdHistorique id ) {

		Historique h = null;
		String per=id.getImmatr();
		String pla=id.getPlace();
		
		if ((per != null  ) && (pla !=null))
			per = per.trim();

		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_FROM_ID);) {
			// associe une valeur au paramètre (IMMATR_PER)
			query.setString(1, per);
			query.setString(3, pla);
			// exécution
			ResultSet rs = query.executeQuery();
			// parcourt du ResultSet
			if (rs.next()) {
				h = new Historique(id,rs.getTimestamp(2).toLocalDateTime() ,rs.getTimestamp(4).toLocalDateTime(),Duration.between(rs.getTimestamp(2).toLocalDateTime(), rs.getTimestamp(4).toLocalDateTime()).toMinutes());
			}
		} catch (SQLException e) {
			logger.error("Erreur SQL ", e);
		}
		return Optional.ofNullable(h);
	}*/

	/**
	 * @param regExpr ne sera pas implémenté ici
	 */
	
	
	public List<Historique> getListe(String regExpr) {
		List<Historique> liste = new ArrayList<>();
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_LISTE)) {
			Historique h=null;
			// charge un ResultSet avec touts les Historiques 
			ResultSet rs = query.executeQuery();
			while (rs.next()) {
				//IdHistorique id=new IdHistorique(rs.getString(1), rs.getString(3));
				// crée un Historique de voiture
				h = new Historique(rs.getTimestamp(2).toLocalDateTime(),rs.getTimestamp(4).toLocalDateTime(), Duration.between(rs.getTimestamp(2).toLocalDateTime(), rs.getTimestamp(4).toLocalDateTime()).toMinutes(),rs.getString(3));
				// ajoute à la liste l'Historique 
				liste.add(h);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du chargement des Historiques", e);
		}
		return liste;
	}

	
	public List<Historique> getHistoriqueVoiture(String immatr) throws Exception{
		List<Historique> liste = new ArrayList<>();
		try (CallableStatement query = factory.getConnexion().prepareCall(SQL_LISTE_HVOIT)) {
			Historique h= null;
		//Associer le Paramètre d'entrée (ordre 1)
		query.setString(1, immatr);
		//Associer le type des paramètres de retour (ordre 2,3,4,5)
		query.registerOutParameter(2, Types.TIMESTAMP);
		query.registerOutParameter(3, Types.TIMESTAMP);
		query.registerOutParameter(4, Types.INTEGER);
		query.registerOutParameter(5, Types.CHAR);
		//Exécution de la requête
		ResultSet rs = query.executeQuery();
		while (rs.next()) {
		//IdHistorique id=new IdHistorique(immatr,rs.getString(4));
		// crée un Historique
		h = new Historique(rs.getTimestamp(1).toLocalDateTime() ,rs.getTimestamp(2).toLocalDateTime(), Duration.between(rs.getTimestamp(1).toLocalDateTime(), rs.getTimestamp(2).toLocalDateTime()).toMinutes(),rs.getString(4));
			// ajoute à la liste l'Historique 
		liste.add(h);
		}
	} catch (SQLException e) {
		logger.error("Erreur lors du chargement des Historiques d'une voiture", e);
		// rollback manuel si pas autocommit
		if (!factory.getConnexion().getAutoCommit())
			this.factory.getConnexion().rollback();
		// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		
	}
	return liste;
		
	}
	
	public List<Historique> getHistoriqueJour(LocalDate jour) throws Exception{
		
		System.out.println(jour);
		String j = jour.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		System.out.println(j);
		List<Historique> liste = new ArrayList<>();
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_LISTE_HJOUR)) {
			//Date date = Date.from(jour.atStartOfDay(ZoneId.systemDefault()).toInstant());
			//Date date = Date.valueOf(jour);
			//System.out.println(date);
			query.setString(1, j);
			
			//query.setString(1, sdf.parse(date));
			//query.setDate(1, date);
			Historique h=null;
			// charge un ResultSet avec toutes les voitures du jour (Historiques)
			ResultSet rs = query.executeQuery();
			//System.out.println(rs);
			while (rs.next()) {
				//IdHistorique id=new IdHistorique(rs.getString(1),rs.getString(3));
				// crée un Historique
				h = new Historique(rs.getTimestamp(2).toLocalDateTime() ,rs.getTimestamp(3).toLocalDateTime(), Duration.between(rs.getTimestamp(2).toLocalDateTime(), rs.getTimestamp(4).toLocalDateTime()).toMinutes(),rs.getString(3));
				// ajoute à la liste l'Historique
				liste.add(h);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du chargement des Historiques d'un jour", e);
			// rollback manuel si pas autocommit
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return liste;
	}
	
	/**
	 * Supprime une Personne
	 */
	/*public boolean delete(IdHistorique id) throws Exception {
		boolean ok = false;
		if (id == null)
			return false;
		int cpt;
		// supprime les éventuels espaces de l'ID
		String immatr = id.getImmatr().trim();
		String code = id.getPlace();
		try (PreparedStatement querySupp = factory.getConnexion().prepareStatement(SQL_DELETE)) {
			// associe le paramètre
			querySupp.setString(1, immatr);
			querySupp.setString(2, code);
			// exécute la suppression
			cpt = querySupp.executeUpdate();
			ok = (cpt != 0);
			if (ok)
				logger.debug("Une historique a été supprimée:", immatr, code);
			// gère le commit et logger
			if (!querySupp.getConnection().getAutoCommit()) {
				logger.debug("Delete en Commit Manuel");
				querySupp.getConnection().commit();
			} else
				logger.debug("Delete en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur de suppression de l'historique " + id.getImmatr(), e);
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return ok;
	}*/

}
