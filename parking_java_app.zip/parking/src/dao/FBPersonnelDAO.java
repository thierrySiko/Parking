package dao;

public class FBPersonnelDAO extends SQLPersonnelDAO {

	public FBPersonnelDAO(SQLDAOFactory factory) {
		super(factory);
	}	

}