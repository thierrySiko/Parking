package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import model.Place;



public abstract class SQLPlaceDAO implements IPlaceDAO{
	private static final String SQL_FROM_CODE = "Select CODE_PLA,TAILLE_PLA,LIBRE_PLA from TPLACE where CODE_PLA=?";
	private static final String SQL_LISTE = "Select CODE_PLA,TAILLE_PLA,LIBRE_PLA from TPLACE";
	private static final String SQL_INSERT = "INSERT INTO TPLACE (CODE_PLA,TAILLE_PLA,LIBRE_PLA) VALUES (?,?,?)";
	private static final String SQL_DELETE = "Delete from TPLACE WHERE CODE_PLA=?";
	private static final String SQL_UPDATE = "update TPLACE set TAILLE_PLA = ?,LIBRE_PLA = ? where trim(CODE_PLA) = ?";

	// Logger
	private static final Logger logger = LoggerFactory.getLogger(SQLPlaceDAO.class);

	// La factory pour avoir la connexion
	private final SQLDAOFactory factory;

	/**
	 * Construction pour avoir l'accès à la factory et ainsi obtenir la connexion
	 * 
	 * @param factory
	 */
	public SQLPlaceDAO(SQLDAOFactory factory) {
		this.factory = factory;
	}

	/**
	 * A partir de son code renvoie un Optional de Place
	 */
	public Optional<Place> getFromID(String code) {

		Place p = null;
		if (code != null)
			code = code.trim();

		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_FROM_CODE);) {
			// associe une valeur au paramètre (CODE_PLA)
			query.setString(1, code);
			// exécution
			ResultSet rs = query.executeQuery();
			// parcourt du ResultSet
			if (rs.next()) {
				p = new Place(code, rs.getInt(2),rs.getBoolean(3));
			}
		} catch (SQLException e) {
			logger.error("Erreur SQL ", e);
		}
		return Optional.ofNullable(p);
	}

	/**
	 * @param regExpr ne sera pas implémenté ici
	 */
	public List<Place> getListe(String regExpr) {
		List<Place> liste = new ArrayList<>();
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_LISTE)) {
			Place p;
			// charge un ResultSet avec toutes les places (Places)
			ResultSet rs = query.executeQuery();
			while (rs.next()) {
				// crée une place
				p = new Place(rs.getString(1).trim(), rs.getInt(2),rs.getBoolean(3));
				// ajoute à la liste la place (Place)
				liste.add(p);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du chargement des Places", e);
		}
		return liste;
	}

	public Place insert(Place p) throws Exception {
		if (p == null)
			return null;
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_INSERT)) {
			// associe les paramètres
			query.setString(1, p.getCode());
			query.setInt(2, p.getTaille());
			query.setBoolean(3, p.getLibre());
			// exécute l'insert
			query.executeUpdate();
			// commit si pas en autocommit et log de l'opération
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Insert en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Insert en AutoCommit");

		} catch (SQLException e) {
			logger.error("Erreur d'insertion de la place ", e);
			// rollback manuel si pas autocommit
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return p;
	}

	/**
	 * Supprime une Place
	 */
	public boolean delete(Place p) throws Exception {
		boolean ok = false;
		if (p == null)
			return false;
		int cpt;
		// supprime les éventuels espaces du code
		String code = p.getCode().trim();
		try (PreparedStatement querySupp = factory.getConnexion().prepareStatement(SQL_DELETE)) {
			// associe le paramètre
			querySupp.setString(1, code);
			// exécute la suppression
			cpt = querySupp.executeUpdate();
			ok = (cpt != 0);
			if (ok)
				logger.debug("Une place a été supprimée:", code);
			// gère le commit et logger
			if (!querySupp.getConnection().getAutoCommit()) {
				logger.debug("Delete en Commit Manuel");
				querySupp.getConnection().commit();
			} else
				logger.debug("Delete en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur de suppression de la place " + p.toString(), e);
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return ok;
	}

	@Override
	public boolean update(Place p) throws Exception {
		if (p == null)
			return false;

		try (PreparedStatement query = this.factory.getConnexion().prepareStatement(SQL_UPDATE)) {
			// associe les paramètres
			query.setInt(1, p.getTaille());
			query.setBoolean(2, p.getLibre());
			query.setString(3, p.getCode());
			// exécute le query
			query.execute();
			// gère l'auto-commit et logger
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Update en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Update en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur de mise à jour d'une place " + p.toString(), e);
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception Spécifique à l'application
			factory.dispatchSpecificException(e);
		}

		return true;
	}

}
