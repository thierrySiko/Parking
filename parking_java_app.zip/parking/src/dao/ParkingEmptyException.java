package dao;

public class ParkingEmptyException extends ParkingException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParkingEmptyException(String msg, int code) {
		super(msg, code);
	}

}
