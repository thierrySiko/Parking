package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import model.Personnel;

public abstract class SQLPersonnelDAO implements IPersonnelDAO {
	private static final String SQL_FROM_ID = "Select IMMATR_PER,NOM_PER,PRENOM_PER,EMAIL_PER from TPERSONNEL where IMMATR_PER=?";
	private static final String SQL_LISTE = "Select IMMATR_PER,NOM_PER,PRENOM_PER,EMAIL_PER from TPERSONNEL";
	private static final String SQL_INSERT = "INSERT INTO TPERSONNEL (IMMATR_PER,NOM_PER,PRENOM_PER,EMAIL_PER) VALUES (?,?,?,?)";
	private static final String SQL_DELETE = "Delete from TPERSONNEL WHERE IMMATR_PER=?";
	private static final String SQL_UPDATE = "update TPERSONNEL set NOM_PER = ?,PRENOM_PER = ?,EMAIL_PER = ? where trim(IMMATR_PER) = ?";

	// Logger
	private static final Logger logger = LoggerFactory.getLogger(SQLPersonnelDAO.class);

	// La factory pour avoir la connexion
	private final SQLDAOFactory factory;

	/**
	 * Construction pour avoir l'accès à la factory et ainsi obtenir la connexion
	 * 
	 * @param factory
	 */
	public SQLPersonnelDAO(SQLDAOFactory factory) {
		this.factory = factory;
	}

	/**
	 * A partir de son id renvoie un Optional de Personnel
	 */
	public Optional<Personnel> getFromID(String id) {

		Personnel p = null;
		if (id != null)
			id = id.trim();

		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_FROM_ID);) {
			// associe une valeur au paramètre (IMMATR_PER)
			query.setString(1, id);
			// exécution
			ResultSet rs = query.executeQuery();
			// parcourt du ResultSet
			if (rs.next()) {
				p = new Personnel(id, rs.getString(2), rs.getString(3), rs.getString(4));
			}
		} catch (SQLException e) {
			logger.error("Erreur SQL ", e);
		}
		return Optional.ofNullable(p);
	}

	/**
	 * @param regExpr ne sera pas implémenté ici
	 */
	public List<Personnel> getListe(String regExpr) {
		List<Personnel> liste = new ArrayList<>();
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_LISTE)) {
			Personnel p;
			// charge un ResultSet avec toutes les voitures (Personnels)
			ResultSet rs = query.executeQuery();
			while (rs.next()) {
				// crée une voiture
				p = new Personnel(rs.getString(1).trim(), rs.getString(2), rs.getString(3), rs.getString(4));
				// ajoute à la liste la voiture (Personnel)
				liste.add(p);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du chargement des Personnes", e);
		}
		return liste;
	}

	public Personnel insert(Personnel p) throws Exception {
		if (p == null)
			return null;
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_INSERT)) {
			// associe les paramètres
			query.setString(1, p.getImmatr());
			query.setString(2, p.getNom());
			query.setString(3, p.getPrenom());
			query.setString(4, p.getEmail());
			// exécute l'insert
			query.executeUpdate();
			// commit si pas en autocommit et log de l'opération
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Insert en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Insert en AutoCommit");

		} catch (SQLException e) {
			logger.error("Erreur d'insertion de la personne ", e);
			// rollback manuel si pas autocommit
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return p;
	}

	/**
	 * Supprime une Personne
	 */
	public boolean delete(Personnel p) throws Exception {
		boolean ok = false;
		if (p == null)
			return false;
		int cpt;
		// supprime les éventuels espaces de l'ID
		String code = p.getImmatr().trim();
		try (PreparedStatement querySupp = factory.getConnexion().prepareStatement(SQL_DELETE)) {
			// associe le paramètre
			querySupp.setString(1, code);
			// exécute la suppression
			cpt = querySupp.executeUpdate();
			ok = (cpt != 0);
			if (ok)
				logger.debug("Une personne a été supprimée:", code);
			// gère le commit et logger
			if (!querySupp.getConnection().getAutoCommit()) {
				logger.debug("Delete en Commit Manuel");
				querySupp.getConnection().commit();
			} else
				logger.debug("Delete en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur de suppression de la personne " + p.toString(), e);
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return ok;
	}

	@Override
	public boolean update(Personnel p) throws Exception {
		if (p == null)
			return false;

		try (PreparedStatement query = this.factory.getConnexion().prepareStatement(SQL_UPDATE)) {
			// associe les paramètres
			query.setString(1, p.getNom());
			query.setString(2, p.getPrenom());
			query.setString(3, p.getEmail());
			query.setString(4, p.getImmatr());
			// exécute le query
			query.execute();
			// gère l'auto-commit et logger
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Update en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Update en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur de mise à jour d'une personne " + p.toString(), e);
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception Spécifique à l'application
			factory.dispatchSpecificException(e);
		}

		return true;
	}
}
