package dao;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Fabrique concrète pour Firebird
 * 
 * @author Didier
 *
 */
public class FBDAOFactory extends SQLDAOFactory {

	public FBDAOFactory(Connection connexion) {
		super(connexion);
	}

	/**
	 * retourne une implémentation DAOPersonnel pour Firebird
	 */
	@Override
	public IPersonnelDAO getPersonnelDAO() {
		return new FBPersonnelDAO(this);
	}
	
	@Override
	public IPlaceDAO getPlaceDAO() {
		return new FBPlaceDAO(this);
	}
	
	@Override
	public IStationnementDAO getStationnementDAO() {
		return new FBStationnementDAO(this);
	}
	
	@Override
	public IHistoriqueDAO getHistoriqueDAO() {
		return new FBHistoriqueDAO(this);
	}
	

	/**
	 * Permet d'extraire le code d'erreur de Firebird et de redispatcher sous une
	 * exception indépendante du système de persistance
	 * 
	 * @param e
	 * @throws ParkingException
	 */
	void dispatchSpecificException(Exception exc) throws ParkingException {
		SQLException e;
		if (!(exc instanceof SQLException))
			throw new ParkingException(exc.getMessage(), -1);
		
		e = (SQLException) exc;
		switch (e.getErrorCode()) {
		case 335544665:// PK
			throw new ParkingPKException(e.getMessage(), e.getErrorCode(), extractFieldPK(e.getMessage()));
		case 335544347:// Contrainte d'unicité, check
			throw new ParkingConstraintException(e.getMessage(), e.getErrorCode(), extractField(e.getMessage()));
		case 335544517:// Contrainte d'unicité, check
			if(e.getMessage().contains("Plein"))
			{
				throw new ParkingFullException(e.getMessage(), e.getErrorCode());
			}
			else if (e.getMessage().contains("non disponible"))
				{
					throw new ParkingPlaceBusyException(e.getMessage(), e.getErrorCode(),extractPlace(e.getMessage()));
				}
				
			
		default:
			throw new ParkingException(e.getMessage(), e.getErrorCode());
		}

	}

	// Permet d'extraire le champ clé primaire du message
	private static String extractFieldPK(String msg) {
		// cherche la première parenthèse ouvrante,
		int pos1 = msg.indexOf('(') + 2;
		return msg.substring(pos1, msg.indexOf('"', pos1));
	}

	// Permet d'extraire du message, le champ qui ne respecte pas une contrainte
	// check
	private static String extractField(String msg) {
		int pos1 = msg.indexOf('.') + 2;
		return msg.substring(pos1, msg.indexOf('"', pos1));
	}
	private static String extractPlace(String msg) {
		int pos1 = msg.indexOf("Place") + 6;
		int pos2 =msg.indexOf("non")-1;
		return msg.substring(pos1, pos2);
	}

}
