package dao;

public class FBPlaceDAO extends SQLPlaceDAO{
	public FBPlaceDAO(SQLDAOFactory factory) {
		super(factory);
	}	

}
