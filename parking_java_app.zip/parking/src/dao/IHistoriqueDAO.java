package dao;

import java.time.LocalDate;
import java.util.List;

import model.Historique;

public interface IHistoriqueDAO extends IDAO<Historique, String>{
	public List<Historique> getHistoriqueVoiture(String immatr) throws Exception;
	public List<Historique> getHistoriqueJour(LocalDate jour) throws Exception;
}
