package dao;

public class ParkingFullException extends ParkingException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParkingFullException(String msg, int code) {
		super(msg, code);
	}

}
