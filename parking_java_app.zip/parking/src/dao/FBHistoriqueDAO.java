package dao;

public class FBHistoriqueDAO extends SQLHistoriqueDAO {

	public FBHistoriqueDAO(SQLDAOFactory factory) {
		super(factory);
	}	
}