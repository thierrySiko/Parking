package dao;

public class FBStationnementDAO extends SQLStationnementDAO{
	public FBStationnementDAO(SQLDAOFactory factory) {
		super(factory);
	}	

}
