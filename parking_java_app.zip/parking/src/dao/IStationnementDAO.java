package dao;

import java.util.List;

import model.InfoSortieVoiture;
import model.Stationnement;

public interface IStationnementDAO extends IDAO<Stationnement, String> {
	public List<String> getListeImmatr(String regExpr);
	public Stationnement arriveeVoiture(String immatr, String place) throws Exception;
	public Stationnement arriveeVoiture(String immatr) throws Exception;
	InfoSortieVoiture sortieVoiture(String immatr) throws Exception;


}
