package dao;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
//import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.InfoSortieVoiture;
import model.Personnel;
import model.Stationnement;


public abstract class SQLStationnementDAO implements IStationnementDAO {
	private static final String SQL_FROM_ID = "Select FKPERSONNE_STA,FKPLACE_STA,MOMENTA_STA from TSTATIONNEMENT where FKPERSONNE_STA=?";
	private static final String SQL_LISTE = "Select FKPERSONNE_STA,FKPLACE_STA,MOMENTA_STA  from TSTATIONNEMENT";
	private static final String SQL_LISTE_IMMATR = "Select FKPERSONNE_STA  from TSTATIONNEMENT";
	private static final String SQL_COUNT = "Select count(FKPERSONNE_STA) from TSTATIONNEMENT";
	public static final String SQL_ARRIVEE_VOIT = "?,?=CALL ARRIVEE_VOIT(?,?)";
	public static final String SQL_SORTIE_VOIT = "?,?=CALL SORTIE_VOIT(?)";

	// Logger
	private static final Logger logger = LoggerFactory.getLogger(SQLStationnementDAO.class);
	// public LocalDateTime l=null;
	// La factory pour avoir la connexion
	private final SQLDAOFactory factory;

	/**
	 * Construction pour avoir l'accès à la factory et ainsi obtenir la connexion
	 * 
	 * @param factory
	 */
	public SQLStationnementDAO(SQLDAOFactory factory) {
		this.factory = factory;
	}

	/**
	 * A partir de son id renvoie un Optional de Stationnement
	 */
	public Optional<Stationnement> getFromID(String id) {

		Stationnement s = null;
		Personnel p = null;
		if (id != null)
			id = id.trim();

		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_FROM_ID);) {
			// associe une valeur au paramètre (FKPERSONNE_STA)
			query.setString(1, id);
			// exécution
			ResultSet rs = query.executeQuery();
			// parcourt du ResultSet
			if (rs.next()) {
				p = new Personnel(id);
				s = new Stationnement(p, rs.getString(2), rs.getTimestamp(3).toLocalDateTime());
			}
		} catch (SQLException e) {
			logger.error("Erreur SQL_ID stationnement ", e);
		}
		return Optional.ofNullable(s);
	}

	/**
	 * @param regExpr ne sera pas implémenté ici
	 */
	public List<Stationnement> getListe(String regExpr) {
		List<Stationnement> liste = new ArrayList<>();
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_LISTE)) {
			Stationnement s;
			// charge un ResultSet avec toutes les Stationnement (Personnels)
			ResultSet rs = query.executeQuery();
			while (rs.next()) {
				Personnel p = new Personnel(rs.getString(1).trim());
				// crée un Stationnement
				s = new Stationnement(p, rs.getString(2), rs.getTimestamp(3).toLocalDateTime());
				// ajoute à la liste le Stationnement (Personnel)
				liste.add(s);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du chargement des Stationnements", e);
		}
		return liste;
	}

	public List<String> getListeImmatr(String regExpr) {
		List<String> liste = new ArrayList<>();
		//ObservableList<String> liste = FXCollections.observableList(l);// new ObservableList<>();
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_LISTE_IMMATR)) {
			String i;
			// charge un ResultSet avec toutes les personnes en Stationnement (Personnels)
			ResultSet rs = query.executeQuery();
			while (rs.next()) {
				// Personnel p = new Personnel(rs.getString(1).trim());
				// crée un Stationnement
				i = rs.getString(1).trim();
				// ajoute à la liste le Stationnement (Personnel)
				liste.add(i);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du chargement des Immatr de Stationnement", e);
		}
		return liste;
	}

	public int count() {
		int c = 0;
		try (PreparedStatement query = factory.getConnexion().prepareStatement(SQL_COUNT)) {
			ResultSet rs = query.executeQuery();
			if (rs.next()) {
				c = rs.getInt(1);
			}
		} catch (SQLException e) {
			logger.error("Erreur lors du count des Stationnements", e);
		}
		return c;
	}

	public Stationnement arriveeVoiture(String immatr, String place) throws Exception {
		Personnel p = null;
		Stationnement s = null;
		try (CallableStatement query = factory.getConnexion().prepareCall(SQL_ARRIVEE_VOIT)) {

			// Associer les Paramètres d'entrée (ordre 1 et 2)
			query.setString(1, immatr);
			query.setString(2, place);
			// Associer le type des paramètres de retour (ordre 3 et 4)
			query.registerOutParameter(3, Types.VARCHAR);
			query.registerOutParameter(4, Types.TIMESTAMP);
			// Exécution de la requête
			ResultSet rs = query.executeQuery();
			if (rs.next()) {
				p = new Personnel(immatr);
				// crée un stationnement
				s = new Stationnement(p, rs.getString(1), rs.getTimestamp(2).toLocalDateTime());
			}
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Arrivee voiture en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Arrivee voiture en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur lors de l 'arrivee d'une voiture", e);
			// rollback manuel si pas autocommit
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return s;
	}

	public Stationnement arriveeVoiture(String immatr) throws Exception {
		Personnel p = null;
		Stationnement s = null;
		try (CallableStatement query = factory.getConnexion().prepareCall(SQL_ARRIVEE_VOIT)) {

			// Associer les Paramètres d'entrée (ordre 1 et 2)
			query.setString(1, immatr);
			query.setString(2, null);
			// Associer le type des paramètres de retour (ordre 3 et 4)
			query.registerOutParameter(3, Types.VARCHAR);
			query.registerOutParameter(4, Types.TIMESTAMP);
			// Exécution de la requête
			ResultSet rs = query.executeQuery();
			if (rs.next()) {
				p = new Personnel(immatr);
				// crée un stationnement
				s = new Stationnement(p, rs.getString(1), rs.getTimestamp(2).toLocalDateTime());
			}
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Arrivee voiture en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Arrivee voiture en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur lors de l 'arrivee d'une voiture", e);
			// rollback manuel si pas autocommit
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return s;
	}

	public InfoSortieVoiture sortieVoiture(String immatr) throws Exception {
		InfoSortieVoiture i = null;
		try (CallableStatement query = factory.getConnexion().prepareCall(SQL_SORTIE_VOIT)) {

			// Associer les Paramètres d'entrée (ordre 1 )
			query.setString(1, immatr);
			// Associer le type des paramètres de retour (ordre 2 et 3)
			query.registerOutParameter(2, Types.VARCHAR);
			query.registerOutParameter(3, Types.INTEGER);
			// Exécution de la requête
			ResultSet rs = query.executeQuery();
			if (rs.next()) {
				// crée une InfoSortieVoiture
				i = new InfoSortieVoiture(immatr, rs.getString(1), rs.getInt(2));
			}
			if (!query.getConnection().getAutoCommit()) {
				logger.debug("Sortie voiture en Commit Manuel");
				query.getConnection().commit();
			} else
				logger.debug("Sortie voiture en AutoCommit");
		} catch (SQLException e) {
			logger.error("Erreur lors de la sortie d'une voiture", e);
			// rollback manuel si pas autocommit
			if (!factory.getConnexion().getAutoCommit())
				this.factory.getConnexion().rollback();
			// transforme l'exception SQL en Exception spécifique à l'application
			factory.dispatchSpecificException(e);
		}
		return i;
	}

}
