package controller;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.DAOFactory;
import dao.DAOFactory.TypePersistance;
import database.connexion.ConnexionFromFile;
import database.connexion.ConnexionSingleton;
import database.connexion.PersistanceException;
import database.uri.Databases;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Place;
import model.Stationnement;
import service.IServiceArrivee;
import service.IServiceHistorique;
import service.IServicePersonnel;
import service.IservicePlace;
import service.Message;
//import service.IServiceSortie;
import service.ServiceArrivee;
import service.ServiceHistorique;
import service.ServicePersonnel;
import service.ServicePlace;
//import service.ServiceSortie;
import view.borneSortie.VueBorneSortieController;
import view.listeHistorique.VueListeHistoriqueController;
import view.listePersonnel.VueListePersonnelController;
import view.listePlace.VueListePlaceController;
import view.listeStationnement.ListeStationnement;

public class ParkingCtrl extends Application implements Subscriber<Message<Place>>  {
	
	// Logger
		static Logger logger = LoggerFactory.getLogger(ParkingCtrl.class);
	
	private Subscription subscription;
	
	private ListeStationnement listStationnement;
	
	// Locale par défaut de l'application
	private final Locale localFR = new Locale("fr", "BE");
	// private final Locale localEN = new Locale("en", "EN");

	// Vues
	private Stage mainStage;

	/******* factory ************/
	private DAOFactory factory;
	/********** Services ************/
	private IServiceArrivee serviceBorneIn;

	private IServiceArrivee serviceBorneOut;
	
	private IServiceArrivee serviceStationnement;

	private IServicePersonnel servicePersonnel;

	private IservicePlace servicePlace;
	
	private IServiceHistorique serviceHistorique;

	/********** Vues ****************/
	// gestionnaire de la vue pour ajouter/modifier une personne
	private GetionnaireVuePersonnel gestionVuePersonnel;
	/********** Vues ****************/
	// gestionnaire de la vue pour ajouter/modifier une personne
	private GestionnaireVuePlace gestionVuePlace;
	// liste et suppression
	private Stage vueListePersonnel = null;

	// liste et suppression
	private Stage vueListePlace = null;
	
	// liste et suppression
		private Stage vueListeHistorique = null;

	private Stage vueBorneSortie = null;

	/**
	 * Création de la fenêtre de l'application
	 */
	@Override
	public void start(Stage primaryStage) {
		Locale.setDefault(localFR);
		// Crée la factory
		createConnexion();
		// couche de service pour arrivée voiture
		serviceBorneIn = new ServiceArrivee(factory.getPlaceDAO(), factory.getStationnementDAO());// new
																									// ServiceArrivee(factory);
		// couche de service pour sortie voiture
		serviceBorneOut = new ServiceArrivee(factory.getPlaceDAO(), factory.getStationnementDAO());

		// Couche de service pour gérer le personel
		servicePersonnel = new ServicePersonnel(factory.getPersonnelDAO());

		// Couche de service pour gérer la lace
		servicePlace = new ServicePlace(factory.getPlaceDAO());
		
		// Couche de service pour gérer la lace
		serviceHistorique = new ServiceHistorique(factory.getHistoriqueDAO());
		
		serviceStationnement = new ServiceArrivee(factory.getPlaceDAO(), factory.getStationnementDAO());
		
		serviceStationnement.addObserver(this);
		
		// Création de la vue Principale
		mainStage = primaryStage;
		BorderPane cp = new BorderPane();

		// Le panneau de boutons
		VBox paneBoutons = new VBox();
		// Borne d'entrée
		Button btBorneIn = new Button("BorneIn");
		btBorneIn.setOnAction((e) -> showBorneEntree(serviceBorneIn));
		// Borne de sortie
		Button btBorneOut = new Button("BorneOut");
		btBorneOut.setOnAction((e) -> showBorneSortie(serviceBorneOut));
		// Vue Personnel
		Button btVuePersonnel = new Button("Personnel");
		btVuePersonnel.setOnAction(e -> gestionVuePersonnel.ajoutPersonne());
		// Vue Personnel
		Button btVuePlace = new Button("Place");
		btVuePlace.setOnAction(e -> gestionVuePlace.ajoutPlace());
		// Vue Liste du personnel
		Button btListePersonnel = new Button("ListePersonnel");
		btListePersonnel.setOnAction(a -> {
			showVueListePersonnel(servicePersonnel);
		});
		// Vue Liste historiques du personnel
		Button btListeHistorique = new Button("ListeHistorique");
		btListeHistorique.setOnAction(a -> {
			showVueListeHistorique(serviceHistorique);
		});

		// Vue Liste des places
		Button btListePlace = new Button("ListePlace");
		btListePlace.setOnAction(a -> {
			showVueListePlace(servicePlace);
		});

		Button btTest = new Button("Test modif personne");
		btTest.setOnAction(e -> gestionVuePersonnel.modifierPersonne("AAA-111"));

		Button btTestP = new Button("Test modif place");
		btTestP.setOnAction(e -> gestionVuePlace.modifierPlace("P01"));
		// Creation du gestionnaire de la vue Personnel
		gestionVuePersonnel = new GetionnaireVuePersonnel(primaryStage, servicePersonnel, this::showErreur);

		// Creation du gestionnaire de la vue Personnel
		gestionVuePlace = new GestionnaireVuePlace(primaryStage, servicePlace, this::showErreur);

		// Ajout les boutons à la liste et la place sur la gauche du BorderPane
		paneBoutons.getChildren().addAll(btBorneIn, btBorneOut, btVuePlace, btVuePersonnel, btListePersonnel,
				btListePlace,btListeHistorique ,btTest, btTestP);
		cp.setLeft(paneBoutons);
		listStationnement=new ListeStationnement(serviceStationnement);
		cp.setCenter(listStationnement);
		// Création de la scène et ajout d'un fichier de style CSS
		Scene scene = new Scene(cp, 600, 400);
		scene.getStylesheets().add("./view/css/parking.css");
		
		// panneau status
				
		//serviceStationnement.addObserverS(this);;
		//setBottom(listStationnement);

		// Ajoute la scene à la primaryStage
		primaryStage.setScene(scene);
		// Affiche la vue
		primaryStage.show();
	}
	
	

	/**
	 * Création d'une vue pour une borne d'entrée
	 * 
	 * @param service
	 */
	private void showBorneEntree(IServiceArrivee service) {

		// Créé une fenêtre avec une vue pour une borne d'entrée
		Stage stage = new Stage();
		stage.initOwner(this.mainStage);
		// stage.setX(100);
		// stage.setY(50);
		ResourceBundle bundle = ResourceBundle.getBundle("view.bundles.BorneEntree");
		BorneEntreeCtrl pane = new BorneEntreeCtrl(service, bundle);

		Scene scene = new Scene(pane, 350, 300);
		scene.getStylesheets().add("./view/css/parking.css");
		stage.setTitle((bundle.getString("titre")));
		stage.setScene(scene);

		stage.show();
		// Se désabonne lors de la fermeture
		stage.setOnCloseRequest(e -> pane.getSubscription().cancel());
	}

	/**
	 * Création d'une vue pour une borne de sortie
	 * 
	 * @param service
	 */
	private void showBorneSortie(IServiceArrivee service) {

		// Créé une fenêtre avec une vue pour une borne d'entrée
		Stage stage = new Stage();
		stage.initOwner(this.mainStage);
		// stage.setX(100);
		// stage.setY(50);
		// Créer un loader pour charger la vue FXML
		ResourceBundle bundle;
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/borneSortie/VueBorneSortie.fxml"));
		try {
			bundle = ResourceBundle.getBundle("view.borneSortie.bundles.VueBorneSortie");
			loader.setResources(bundle);
			// Obtenir la traduction du titre dans la locale
			// stage.setTitle(bundle.getString("listePer.titre"));
		} catch (Exception e) {
			showErreur(e.getMessage());
			// stage.setTitle("Vue Liste Personnel");
		}

		// Charge la vue à partir du Loader
		// et initialise son contenu en appelant la méthode setUp du controleur
		BorderPane pane;
		try {
			pane = loader.load();
			// récupère le ctrl (après l'initialisation)
			VueBorneSortieController ctrl = loader.getController();
			// fourni la fabrique au ctrl pour charger les articles
			ctrl.setUp(serviceBorneOut);
			// charge le Pane dans la Stage
			Scene scene = new Scene(pane, 400, 400);
			scene.getStylesheets().add("./view/borneSortie/css/VueBorneSortie.css");
			// stage.setTitle((bundle.getString("titre")));
			stage.setScene(scene);
			stage.show();
			// Se désabonne lors de la fermeture
			stage.setOnCloseRequest(e -> ctrl.getSubscription().cancel());
		} catch (IOException e) {
			showErreur("Impossible de charger la borne de sortie: " + e.getMessage());
			stage = null;
		}
		vueBorneSortie = stage;

		// ResourceBundle bundle = ResourceBundle.getBundle("view.bundles.BorneEntree");
		/*
		 * BorneEntreeCtrl pane = new BorneEntreeCtrl(service, bundle);
		 * 
		 * Scene scene = new Scene(pane, 350, 300);
		 * scene.getStylesheets().add("./view/css/parking.css");
		 * stage.setTitle((bundle.getString("titre"))); stage.setScene(scene);
		 * 
		 * stage.show(); // Se désabonne lors de la fermeture stage.setOnCloseRequest(e
		 * -> pane.getSubscription().cancel());
		 */
	}

	/**
	 * Ouvre une vue avec une liste des voitures du personnel cette liste est à
	 * l'écoute des changements
	 * 
	 * @param servicePersonnel
	 */
	private void showVueListePersonnel(IServicePersonnel servicePersonnel) {
		// vérifie si la vue existe déjà
		if (vueListePersonnel != null)
			vueListePersonnel.show();
		else {
			ResourceBundle bundle;
			// Crée une stage
			Stage stage = new Stage();
			stage.initOwner(this.mainStage);
			stage.setX(150);
			stage.setY(200);

			// Crée un loader pour charger la vue FXML
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/listePersonnel/VueListePersonnel.fxml"));
			try {
				bundle = ResourceBundle.getBundle("view.listePersonnel.bundle.VueListePersonnel");
				loader.setResources(bundle);
				// Obtenir la traduction du titre dans la locale
				stage.setTitle(bundle.getString("listePer.titre"));
			} catch (Exception e) {
				showErreur(e.getMessage());
				stage.setTitle("Vue Liste Personnel");
			}
			// Charge la vue à partir du Loader
			// et initialise son contenu en appelant la méthode setUp du controleur
			AnchorPane root;
			try {
				root = loader.load();
				// récupère le ctrl (après l'initialisation)
				VueListePersonnelController ctrl = loader.getController();
				// fourni la fabrique au ctrl pour charger les articles
				ctrl.setUp(servicePersonnel);
				// charge le Pane dans la Stage
				Scene scene = new Scene(root, 400, 400);
				scene.getStylesheets().add("./view/css/parking.css");
				stage.setScene(scene);
				stage.show();
			} catch (IOException e) {
				showErreur("Impossible de charger la liste du personnel: " + e.getMessage());
				stage = null;
			}
			vueListePersonnel = stage;
		}

	}

	private void showVueListePlace(IservicePlace servicePlace) {
		// vérifie si la vue existe déjà
		if (vueListePlace != null)
			vueListePlace.show();
		else {
			ResourceBundle bundle;
			// Crée une stage
			Stage stage = new Stage();
			stage.initOwner(this.mainStage);
			stage.setX(150);
			stage.setY(200);

			// Crée un loader pour charger la vue FXML
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/listePlace/VueListePlace.fxml"));
			try {
				bundle = ResourceBundle.getBundle("view.listePlace.bundle.VueListePlace");
				loader.setResources(bundle);
				// Obtenir la traduction du titre dans la locale
				stage.setTitle(bundle.getString("listePla.titre"));
			} catch (Exception e) {
				showErreur(e.getMessage());
				stage.setTitle("Vue Liste Place");
			}
			// Charge la vue à partir du Loader
			// et initialise son contenu en appelant la méthode setUp du controleur
			AnchorPane root;
			try {
				root = loader.load();
				// récupère le ctrl (après l'initialisation)
				VueListePlaceController ctrl = loader.getController();
				// fourni la fabrique au ctrl pour charger les articles
				ctrl.setUp(servicePlace);
				// charge le Pane dans la Stage
				Scene scene = new Scene(root, 400, 400);
				scene.getStylesheets().add("./view/css/parking.css");
				stage.setScene(scene);
				stage.show();
			} catch (IOException e) {
				showErreur("Impossible de charger la liste des places: " + e.getMessage());
				stage = null;
			}
			vueListePlace = stage;
		}

	}
	
	private void showVueListeHistorique(IServiceHistorique serviceHistorique) {
		// vérifie si la vue existe déjà
		if (vueListeHistorique != null)
			vueListeHistorique.show();
		else {
			ResourceBundle bundle;
			// Crée une stage
			Stage stage = new Stage();
			stage.initOwner(this.mainStage);
			stage.setX(150);
			stage.setY(200);

			// Crée un loader pour charger la vue FXML
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/listeHistorique/VueListeHistorique.fxml"));
			try {
				bundle = ResourceBundle.getBundle("view.listeHistorique.bundle.VueListeHistorique");
				loader.setResources(bundle);
				// Obtenir la traduction du titre dans la locale
				stage.setTitle(bundle.getString("listeHis.titre"));
			} catch (Exception e) {
				showErreur(e.getMessage());
				stage.setTitle("Vue Liste Historiques");
			}
			// Charge la vue à partir du Loader
			// et initialise son contenu en appelant la méthode setUp du controleur
			AnchorPane root;
			try {
				root = loader.load();
				// récupère le ctrl (après l'initialisation)
				VueListeHistoriqueController ctrl = loader.getController();
				// fourni la fabrique au ctrl pour charger les articles
				ctrl.setUp(serviceHistorique);
				// charge le Pane dans la Stage
				Scene scene = new Scene(root, 400, 400);
				scene.getStylesheets().add("./view/css/parking.css");
				stage.setScene(scene);
				stage.show();
			} catch (IOException e) {
				showErreur("Impossible de charger la liste des historiques: " + e.getMessage());
				stage = null;
			}
			vueListeHistorique = stage;
		}

	}

	/**
	 * Création du DAO et la connexion à la BD
	 */
	private void createConnexion() {
		try {
			ConnexionSingleton.setInfoConnexion(
					new ConnexionFromFile("./resources/connexionParking.properties", Databases.FIREBIRD));
			factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, ConnexionSingleton.getConnexion());
		} catch (PersistanceException e) {
			showErreur(e.getMessage());
			Platform.exit();
		}
	}

	/**
	 * Vue pour afficher les messages d'erreur
	 * 
	 * @param message
	 */
	private void showErreur(String message) {
		Alert a = new Alert(AlertType.ERROR, message);
		a.showAndWait();
	}

	/**
	 * Lancement de l'application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
	
	/****************** GESTION PUBLICATION ********************/

	// Gestion des publications
	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscription = subscription;
		subscription.request(10);
		logger.info("Je suis un écouteur de place");
	}

	// Reception des messages
	@Override
	public void onNext(Message<Place> item) {
		
		 ObservableList<Stationnement> loStationnement =  listStationnement.getListeObs();
		//ObservableList<Stationnement> loStationnement = listStationnement.getListeObs();
		 TableView<Stationnement> tblStationnement = listStationnement.getTableView();
		 TextField ztCpt = listStationnement.getTextField();
		 List<Stationnement> stationnement = serviceStationnement.getListeStationnemnt();
		 loStationnement = FXCollections.observableList(stationnement);
		// Donne la liste observable à la TableView
			tblStationnement.setItems(loStationnement);
		/*ObservableList<Stationnement> loStationnement = listStationnement.getListeObs();
		TableView<Stationnement> tblStationnement = listStationnement.getTableView();
		TextField ztCpt = listStationnement.getTextField();*/
		logger.info(item.getOp() + " sur " + item.getElement());
		switch (item.getOp()) {
		case INSERT:
			// Platform.runLater(()->loStationnement.add(item.getElement()));
			Platform.runLater(() -> {
				/*ObservableList<Stationnement> loStationnement = listStationnement.getListeObs();
				TableView<Stationnement> tblStationnement = listStationnement.getTableView();
				TextField ztCpt = listStationnement.getTextField();*/
				// charge les stationnements
				//List<Stationnement> stationnement = serviceStationnement.getListeStationnemnt();
				// Transforme la liste en une liste observable
				
				// Donne la liste observable à la TableView
				//tblStationnement.setItems(loStationnement);
				// Ajuste la zone de texte avec la taille
				ztCpt.setText(Integer.toString(stationnement.size()));
			});
			break;
		case DELETE:
			// Platform.runLater(()->loStationnement.remove(item.getElement()));
			break;
		case UPDATE:
			/*
			 * { //recherche la voiture dans la liste cpt=-1; Optional<Stationnement> op =
			 * loStationnement.stream().filter((p)-> {cpt++;return
			 * p.getPersonne().getImmatr().equals(item.getElement().getPersonne().getImmatr(
			 * ));}).findFirst(); if(op.isPresent())
			 * Platform.runLater(()->loStationnement.set(cpt, item.getElement())); }
			 */
			Platform.runLater(() -> {
				/*ObservableList<Stationnement> loStationnement = listStationnement.getListeObs();
				TableView<Stationnement> tblStationnement = listStationnement.getTableView();
				TextField ztCpt = listStationnement.getTextField();*/
				// charge les stationnements
				//List<Stationnement> stationnement = serviceStationnement.getListeStationnemnt();
				// Transforme la liste en une liste observable
				//loStationnement = FXCollections.observableList(stationnement);
				// Donne la liste observable à la TableView
				//tblStationnement.setItems(loStationnement);
				// Ajuste la zone de texte avec la taille
				ztCpt.setText(Integer.toString(stationnement.size()));
			});
			break;
		default:
			break;
		}
		/*ObservableList<Stationnement> loStationnement = listStationnement.getListeObs();
		List<Stationnement> stationnement = serviceStationnement.getListeStationnemnt();*/
		// Transforme la liste en une liste observable
		//loStationnement = FXCollections.observableList(stationnement);
		//TextField ztCpt = listStationnement.getTextField();
	//Platform.runLater(() -> ztCpt.setText(Integer.toString(loStationnement.size())));
		subscription.request(1);
	}

	@Override
	public void onError(Throwable throwable) {
		logger.error("erreur d'abonnement aux stationnements de personne");

	}

	@Override
	public void onComplete() {
		logger.info(" écouteur de stationnement On Complete");
	}

	// Permet d'avoir la "Subscription pour se désabonner"
	public Subscription getSubscription() {
		return subscription;
	}

	

}
