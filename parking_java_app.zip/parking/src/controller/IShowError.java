package controller;

@FunctionalInterface
public interface IShowError {
	void showError(String msg);
}
