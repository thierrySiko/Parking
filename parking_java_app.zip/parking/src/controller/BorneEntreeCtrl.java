package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.ParkingException;
import dao.ParkingFullException;
import dao.ParkingPKException;
import dao.ParkingPlaceBusyException;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import model.Place;
import model.Stationnement;
import service.IServiceArrivee;
import service.Message;
import view.statusBar.StatusBar;
import view.statusBar.StatusBar.TypeMessage;


public class BorneEntreeCtrl extends BorderPane implements  Subscriber<Message<Place>>  {
	private ResourceBundle bundle;
	private IServiceArrivee service;
	private StatusBar statusBar;
	// Logger
	static Logger logger = LoggerFactory.getLogger(BorneEntreeCtrl.class);

	//Pseudo class pour l'occupation d'une place
	private final PseudoClass busyClass = PseudoClass.getPseudoClass("busy");
	//Maintient un lien entre chaque bouton et le code sa place
	private Map<String,Button> boutons= new HashMap<>();
	private Subscription subscription;

	/**
	 * 
	 * @param service
	 */
	public BorneEntreeCtrl(IServiceArrivee service, ResourceBundle bundle) {
		super();
		this.service = service;
		this.bundle = bundle;
		
		create();
		service.addObserver(this);
		//service.addObserverS(this);
	}

	/**
	 * Permet de renvoyé la clé i18n adaptée à l'exception
	 * 
	 * @param e
	 * @return
	 */
	private String showErreur(ParkingException e) {
		if (e instanceof ParkingFullException)
			return bundle.getString("Plein");
		if (e instanceof ParkingPlaceBusyException)
			return ((ParkingPlaceBusyException)e).getPlace() +" "+ bundle.getString("PlaceBusy") ;
		if (e instanceof ParkingPKException)
			return bundle.getString("AlreadyIn");
		if (e instanceof ParkingException)
			return bundle.getString("Unknown");
		return "ERROR X";
	}

	/**
	 * Crée les éléments de la vue
	 */
	private void create() {
		// Récupère les places
		List<Place> places = service.getListePlace();

		// panneau haut
		HBox ph = new HBox(5);
		Label txt = new Label(bundle.getString("plaque"));
		TextField plaque = new TextField();
		Label txtP = new Label(bundle.getString("place"));
		TextField place = new TextField();
		// permet de rendre la zone de texte extensible avec la fenêtre
		HBox.setHgrow(plaque, Priority.ALWAYS);
		Button btAutoIn = new Button(bundle.getString("autoIn"));
		btAutoIn.setOnAction(e -> {
			if(place.getText().isEmpty())
			{
			try {
				Stationnement s = service.arriveeVoit(plaque.getText(), null);
				// Affiche l'information dans la barre de status
				String msg = s.getPersonne().getImmatr() + " " + bundle.getString("VoitPlace") + s.getPlace();
				statusBar.setInfoStatus(msg,TypeMessage.INFO);
			} catch (ParkingException exc) {
				statusBar.setInfoStatus(showErreur(exc),TypeMessage.INFO);
			}}
			else {
				try {
					Stationnement s = service.arriveeVoit(plaque.getText(), place.getText());
					// Affiche l'information dans la barre de status
					String msg = s.getPersonne().getImmatr() + " " + bundle.getString("VoitPlace") + s.getPlace();
					statusBar.setInfoStatus(msg,TypeMessage.INFO);
				} catch (ParkingException exc) {
					statusBar.setInfoStatus(showErreur(exc),TypeMessage.INFO);
				}
				
			}
		});
		ph.getChildren().addAll(txt, plaque, txtP, place, btAutoIn);
		ph.getStyleClass().add("b-in-hbox");
		//ph.setPadding(new Insets(5));
		setTop(ph);

		// Panneau centre
		GridPane pPlaces = new GridPane();
		pPlaces.setPadding(new Insets(5.0));
		pPlaces.setHgap(5);
		pPlaces.setVgap(5);
		pPlaces.setAlignment(Pos.CENTER);
		Button btPlace;
		boutons.clear();//Vide la map
		int ligne = -1;// ligne de départ pour le bouton
		int colonne = 0;// colonne de départ pour place
		for (Place p : places) {
			// Texte du bouton contient le code de la place
			btPlace = new Button(p.getCode());
			btPlace.pseudoClassStateChanged(busyClass, !p.getLibre());
			btPlace.getStyleClass().add("bt-place");
			boutons.put(p.getCode(),btPlace);
			btPlace.setOnAction(e -> {
				String msg;
				try {
					Stationnement s = service.arriveeVoit(plaque.getText(), p.getCode());
					msg = s.getPersonne().getImmatr() + " " + bundle.getString("VoitPlace") + s.getPlace();
					// Affiche l'information dans la barre de status
					statusBar.setInfoStatus(msg,StatusBar.TypeMessage.INFO);
				} catch (ParkingException exc) {
					statusBar.setInfoStatus(showErreur(exc),StatusBar.TypeMessage.ERROR);
				}
			});
			if (p.getTaille() > 5) {
				// Grande place
				ligne++;
				
				GridPane.setHalignment(btPlace, HPos.CENTER);
				btPlace.setPrefWidth(155);
				pPlaces.add(btPlace, 0, ligne, 2, 1);
				colonne = 0;
			} else {
				btPlace.setPrefWidth(75);
				if (colonne == 0)
					ligne++;
				pPlaces.add(btPlace, colonne, ligne, 1, 1);
				colonne = (colonne + 1) % 2;
			}
		}

		setCenter(pPlaces);
		// panneau status
		statusBar=new StatusBar();
		setBottom(statusBar);
	}
	/****************** GESTION PUBLICATION ********************/

	//Gestion des publications
		@Override
		public void onSubscribe(Subscription subscription) {
			this.subscription = subscription;
			subscription.request(10);
			logger.info("Je suis un écouteur de Stationnement Borne In");
		}

	//Reception des messages
		@Override
		public void onNext(Message<Place> item) {
			logger.info(item.getOp() + " sur " + item.getElement());
			Place p=item.getElement();
			Button bt= boutons.get(p.getCode());
	
			switch (item.getOp()) {
			case INSERT:
			
				break;
			case DELETE:
				
				break;
			case UPDATE:
				if (bt!=null) 
					Platform.runLater(()->bt.pseudoClassStateChanged(busyClass, !p.getLibre()));
			default:
				break;
			}
			subscription.request(1);
		}

		@Override
		public void onError(Throwable throwable) {
			logger.error("erreur d'abonnement à la borne d'entrée");

		}

		@Override
		public void onComplete() {
			logger.info(" écouteur de BorneIn On Complete");
		}

		//Permet d'avoir la "Subscription pour se désabonner"
		public Subscription getSubscription() {
			return subscription;
		}	

}
