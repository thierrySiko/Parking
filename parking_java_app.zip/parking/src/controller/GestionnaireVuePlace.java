package controller;

import java.io.IOException;
import java.util.Optional;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Place;
import service.IservicePlace;
import view.place.VuePlaceController;

public class GestionnaireVuePlace {

	// la fenêtre parent (celle de l'application en principe)
	private Stage mainStage;
	// la vue Personnel
	private Stage vuePlace = null;
	// le controleur
	private VuePlaceController vuePlaceCtrl;
	// la couche de service
	private IservicePlace servicePlace;

	// la méthode a appeler pour afficher les erreurs
	private IShowError traitementErreur;

	private static final Logger logger = LoggerFactory.getLogger(GestionnaireVuePlace.class);

	/**
	 * Donne toutes les informations nécessaires pour créer et utiliser la vuePlace
	 * 
	 * @param mainStage        fenêtre principale de l'application
	 * @param service          le service d'accès à la place
	 * @param traitementErreur la méthode à appeler pour afficher les erreurs
	 */
	GestionnaireVuePlace(Stage mainStage, IservicePlace service, IShowError traitementErreur) {
		this.servicePlace = service;
		this.mainStage = mainStage;
		this.traitementErreur = traitementErreur;
	}

	/**
	 * Création de la vue FXML avec son ctrl avec le chargement des bundles
	 * 
	 */
	private void createVue() {
		ResourceBundle bundle;
		// Crée une stage
		Stage stage = new Stage();
		stage.initOwner(this.mainStage);
		stage.initModality(Modality.WINDOW_MODAL);
		stage.setX(150);
		stage.setY(100);

		// Crée un loader pour charger la vue FXML
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/place/VuePlace.fxml"));
		try {// remarque: le chemin d'un bundle se fait avec des points
			bundle = ResourceBundle.getBundle("view.place.bundles.VuePlace");
			loader.setResources(bundle);
			// Obtenir la traduction du titre dans la locale
			stage.setTitle(bundle.getString("place.titre"));
		} catch (Exception e) {
			logger.error(e.getMessage());
			stage.setTitle("Vue Place");
		}
		// Charge la vue à partir du Loader
		// et initialise son contenu en appelant la méthode setUp du controleur
		BorderPane root;
		try {
			root = loader.load();
			// récupère le ctrl (après l'initialisation)
			vuePlaceCtrl = loader.getController();
			// fourni la fabrique au ctrl pour charger les articles
			vuePlaceCtrl.setUp(servicePlace, stage);
			// charge le Pane dans la Stage
			Scene scene = new Scene(root, 400, 400);
			scene.getStylesheets().add("./view/place/css/VuePlace.css");
			stage.setScene(scene);

		} catch (IOException e) {
			String erreur = "Impossible de charger la vue place: " + e.getMessage();
			logger.error(erreur);
			traitementErreur.showError(erreur);
			stage = null;
		}
		vuePlace = stage;
	}

	/**
	 * Méthode pour ajouter une personne
	 */
	void ajoutPlace() {
		// Crée la vue si elle n'existe pas encore
		if (vuePlace == null)
			createVue();
		// vérifie si elle a bien été créer
		if (vuePlace != null)
			vuePlaceCtrl.ajouterPlace();
	}

	/**
	 * méthode pour modifier une place
	 * 
	 * @param p la place a modifier
	 */
	void modifierPlace(Place p) {
		if (p == null)
			traitementErreur.showError("Place à modifier est à null:");
		if (vuePlace == null)
			createVue();
		if (vuePlace != null)
			vuePlaceCtrl.modifierPlace(p);
	}

	/**
	 * Modifier une place à partir de son id
	 * 
	 * @param code le code de la place
	 */
	void modifierPlace(String code) {
		// crée la vue si elle n'existe pas
		if (vuePlace == null)
			createVue();
		// si elle existe
		if (vuePlace != null) {
			// recherche la personne
			Optional<Place> op = servicePlace.getFromID(code);

			// appelle la maj sinon affiche l'erreur
			op.ifPresentOrElse(p -> vuePlaceCtrl.modifierPlace(p),
					() -> traitementErreur.showError("Place inexistante: " + code));
		}
	}

}
