package model;

import java.time.LocalDateTime;

public class Stationnement {
	private final Personnel personne;
	//private final String immatr;
	private final String place;
	private final LocalDateTime momentA;
	
	/**
	 * @param personne
	 * @param place
	 * @param momentA
	 */
	public Stationnement(Personnel personne, String place, LocalDateTime momentA) {
		//super();
		this.personne = personne;
		this.place = place;
		this.momentA = momentA;
		//this.immatr = null;
	}
	/*public Stationnement(String immatr, String place, LocalDateTime momentA) {
		//super();
		this.immatr = immatr;
		this.place = place;
		this.momentA = momentA;
		this.personne = null;
	}*/
	public Personnel getPersonne() {
		return personne;
	}
	/*public String getImmatr() {
		return immatr;
	}*/
	public String getPlace() {
		return place;
	}
	public LocalDateTime getMomentA() {
		return momentA;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((momentA == null) ? 0 : momentA.hashCode());
		result = prime * result + ((personne == null) ? 0 : personne.hashCode());
		result = prime * result + ((place == null) ? 0 : place.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stationnement other = (Stationnement) obj;
		if (momentA == null) {
			if (other.momentA != null)
				return false;
		} else if (!momentA.equals(other.momentA))
			return false;
		if (personne == null) {
			if (other.personne != null)
				return false;
		} else if (!personne.equals(other.personne))
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Stationnement [personne=" + personne + ", place=" + place + ", momentA=" + momentA + "]";
	}
	
	
	
	
	
	

}
