package model;

public class Place {
	private String code;
	private Integer taille;
	private Boolean libre;

	/**
	 * @param code
	 * @param taille
	 * @param libre
	 */
	public Place(String code, Integer taille, Boolean libre) {
		super();
		this.code = code;
		this.taille = taille;
		this.libre = libre;
	}
	
	public Place(String code, int taille) {
		this(code, taille, true);
	}

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Integer getTaille() {
		return taille;
	}

	public void setTaille(Integer taille) {
		this.taille = taille;
	}

	public Boolean getLibre() {
		return libre;
	}

	public void setLibre(Boolean libre) {
		this.libre = libre;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((libre == null) ? 0 : libre.hashCode());
		result = prime * result + ((taille == null) ? 0 : taille.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Place other = (Place) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (libre == null) {
			if (other.libre != null)
				return false;
		} else if (!libre.equals(other.libre))
			return false;
		if (taille == null) {
			if (other.taille != null)
				return false;
		} else if (!taille.equals(other.taille))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Place [code=" + code + ", taille=" + taille + ", libre=" + libre + "]";
	}

}
