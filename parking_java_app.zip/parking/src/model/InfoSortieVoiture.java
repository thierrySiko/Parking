package model;

public class InfoSortieVoiture {
	private final String immatr;
	private final String place;
	private final long minutes;
	/**
	 * @param immatr
	 * @param place
	 * @param minutes
	 */
	public InfoSortieVoiture(String immatr, String place, long minutes) {
		super();
		this.immatr = immatr;
		this.place = place;
		this.minutes = minutes;
	}
	public String getImmatr() {
		return immatr;
	}
	public String getPlace() {
		return place;
	}
	public long getMinutes() {
		return minutes;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((immatr == null) ? 0 : immatr.hashCode());
		result = prime * result + (int) (minutes ^ (minutes >>> 32));
		result = prime * result + ((place == null) ? 0 : place.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InfoSortieVoiture other = (InfoSortieVoiture) obj;
		if (immatr == null) {
			if (other.immatr != null)
				return false;
		} else if (!immatr.equals(other.immatr))
			return false;
		if (minutes != other.minutes)
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "InfoSortieVoiture [immatr=" + immatr + ", place=" + place + ", minutes=" + minutes + "]";
	}
	
	

}
