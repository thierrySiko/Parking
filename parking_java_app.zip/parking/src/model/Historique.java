package model;

import java.time.LocalDateTime;

public class Historique {
	//private final IdHistorique id;
	private final LocalDateTime momentA;
	private final LocalDateTime momentS;
	private final long minutes;
	private final String place;
	/**
	 * @param id
	 * @param momentA
	 * @param momentS
	 * @param minutes
	 */
	public Historique (LocalDateTime momentA, LocalDateTime momentS, long minutes, String place) {
		super();
		//this.id = id;
		this.momentA = momentA;
		this.momentS = momentS;
		this.minutes = minutes;
		this.place = place;
	}
	/*public IdHistorique getId() {
		return id;
	}*/
	public LocalDateTime getMomentA() {
		return momentA;
	}
	public LocalDateTime getMomentS() {
		return momentS;
	}
	public long getMinutes() {
		return minutes;
	}
	
	public String getPlace() {
		return place;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (minutes ^ (minutes >>> 32));
		result = prime * result + ((momentA == null) ? 0 : momentA.hashCode());
		result = prime * result + ((momentS == null) ? 0 : momentS.hashCode());
		result = prime * result + ((place == null) ? 0 : place.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Historique other = (Historique) obj;
		if (minutes != other.minutes)
			return false;
		if (momentA == null) {
			if (other.momentA != null)
				return false;
		} else if (!momentA.equals(other.momentA))
			return false;
		if (momentS == null) {
			if (other.momentS != null)
				return false;
		} else if (!momentS.equals(other.momentS))
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Historique [momentA=" + momentA + ", momentS=" + momentS + ", minutes=" + minutes + ", place=" + place
				+ "]";
	}
	
	
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (int) (minutes ^ (minutes >>> 32));
		result = prime * result + ((momentA == null) ? 0 : momentA.hashCode());
		result = prime * result + ((momentS == null) ? 0 : momentS.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Historique other = (Historique) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (minutes != other.minutes)
			return false;
		if (momentA == null) {
			if (other.momentA != null)
				return false;
		} else if (!momentA.equals(other.momentA))
			return false;
		if (momentS == null) {
			if (other.momentS != null)
				return false;
		} else if (!momentS.equals(other.momentS))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Historique [id=" + id + ", momentA=" + momentA + ", momentS=" + momentS + ", minutes=" + minutes + "]";
	}*/
	
	

}
