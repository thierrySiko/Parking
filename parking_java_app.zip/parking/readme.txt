Les fichiers connexion_*.properties doivent être copiés (ou recréer)
 dans le dossier "resources" du projet.
Ces fichiers devront être adaptés en fonction de l'endroit où 
vous allez mettre les bases de données.
Ces fichiers ne seront pas rajoutés au dépôt GIT!
Ainsi vous pouvez adapter les chemins à votre guise en fonction de votre OS 
et choix personnels. Pour ma part, je les sauve dans "c:\DBS\pdb\"

Je n'ai pas rajouté les fichiers de configuration d'Eclipse à Git pour
avoir plus d'indépendance dans la configuration de l'IDE. Cependant, lors de 
l'importation du projet, il faudra effectuer quelques manipulations en plus:
 *Après la 1ère importation, il faudra créer un nouveau projet Eclipse
 *définir le projet en UTF8
 *...

