package dao;

import static org.testng.Assert.assertEquals;



import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;


import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dao.DAOFactory.TypePersistance;
import database.connexion.ConnexionFromFile;
import database.connexion.ConnexionSingleton;
import database.connexion.PersistanceException;
import database.uri.Databases;
import model.Historique;
import model.IdHistorique;
import utils.DatabaseUtil;


public class TestDaoHistorique {
	private DAOFactory factory;

	private final IdHistorique ida=new IdHistorique("AAA-111","P01");
	private final IdHistorique idb=new IdHistorique("BBB-222","P04");
	/*Date d1 = new Date(); // date courante
	System.out.println("Date actuelle : " + d1);
	// Format
	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");*/
	private LocalDate d = LocalDate.of(2017, 03, 15);
	//private LocalDate date = d.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
	//private final LocalDate date = LocalDate.parse("15-03-2017", DateTimeFormatter.ofPattern("dd-MM-yyyy"));//15.03.2017
	//private final LocalDate date = d.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
	//SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

	/**
	 * Teste un getListe
	 */
	@Test
	public void testGetListeDaoHistorique() {
		IHistoriqueDAO dao = factory.getHistoriqueDAO();
		List<Historique> l = dao.getListe(null);
		assertEquals(l.size(), 6);
		// Vérifie l'id de la première ligne
		assertEquals(l.get(0).getPlace(), ida.getPlace());
		//assertEquals(l.get(0).getPlace(), ida.getPlace());
	}
	

	/**
	 * Teste un GetHistoriqueVoiture
	 */
	@Test
	public void testGetHistoriqueVoiture() throws Exception {
		IHistoriqueDAO dao = factory.getHistoriqueDAO();
		List<Historique> l = dao.getHistoriqueVoiture("BBB-222");
		assertEquals(l.size(), 1);
		// // Vérifie l'id de la première ligne
		assertEquals(l.get(0).getPlace(), idb.getPlace());
		 
	}
	

	/**
	 * Teste un GetHistoriqueJour
	 */
	@Test
	public void testGetHistoriqueJour() throws Exception {
		IHistoriqueDAO dao = factory.getHistoriqueDAO();
		System.out.println(d);
		/*String uneDate = "15-03-2017";
		Date d2 = sdf.parse(uneDate);*/
		
		List<Historique> l = dao.getHistoriqueJour(d);
		assertEquals(l.size(), 0);
		// Vérifie l'id
		//assertEquals(l.get(0).getId(), id);
	}

	
	
	

	
	

	/**
	 * Exécuté une fois et ceci avant tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@BeforeClass
	public void beforeClass() throws PersistanceException, FileNotFoundException {
		ConnexionSingleton.setInfoConnexion(
				new ConnexionFromFile("./resources/connexionParking_Test.properties", Databases.FIREBIRD));
		// Réinitialise la base de données dans son état initial
		// DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./resources/scriptInitDBTest.sql");
		factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, ConnexionSingleton.getConnexion());
	}

	/**
	 * Exécuté une fois et ceci après tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@AfterClass
	public void afterClass() throws FileNotFoundException, PersistanceException {
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./resources/scriptInitDBTest.sql");
		ConnexionSingleton.liberationConnexion();
	}

}
