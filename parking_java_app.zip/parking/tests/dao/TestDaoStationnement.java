package dao;

import static org.testng.Assert.assertEquals;


import static org.testng.Assert.assertTrue;

import java.io.FileNotFoundException;

import java.util.List;
import java.util.Optional;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dao.DAOFactory.TypePersistance;
import database.connexion.ConnexionFromFile;
import database.connexion.ConnexionSingleton;
import database.connexion.PersistanceException;
import database.uri.Databases;
import model.InfoSortieVoiture;
import model.Personnel;
import model.Stationnement;
import utils.DatabaseUtil;


public class TestDaoStationnement {
	private DAOFactory factory;

	private final Personnel pa = new Personnel("CCC-333" , "", "", "");
	private final Personnel pb = new Personnel("BBB-222", "", "", "");
	//LocalDateTime sDateTimeA = LocalDateTime.of(2017, 03, 28, 17, 07, 45,745);//28.03.2017, 17:07:45.745
	//LocalDateTime sDateTimeS = LocalDateTime.of(2018, 03, 15, 14, 38, 13,739);//15.03.2018, 14:38:13.739
	//private final long min = Duration.between(sDateTimeA,sDateTimeS).toMinutes();
	//private final Stationnement sa = new Stationnement(pa, "P01",sDateTimeA);
	//private final InfoSortieVoiture ia = new InfoSortieVoiture(pa.getImmatr(),"P01", min);

	/**
	 * Test un getFromId
	 */
	@Test
	public void testGetDaoStationnement() {
		IStationnementDAO dao = factory.getStationnementDAO();
		Optional<Stationnement> s = dao.getFromID(pa.getImmatr());
		// Vérifie si l'objet existe
		assertTrue(s.isPresent());
		assertEquals(s.get().getPersonne(), pa);
		assertEquals(s.get().getPlace(), "P01");
		
	}

	/**
	 * Teste un getListe
	 */
	@Test
	public void testGetListeDaoStationnement() {
		IStationnementDAO dao = factory.getStationnementDAO();
		List<Stationnement> l = dao.getListe(null);
		assertEquals(l.size(), 1);
		System.out.println(l);
		// Vérifie si sa existe dans la liste
		assertEquals(l.get(0).getPersonne(), pa);
	}
	
	/**
	 * Teste un count
	 */
	@Test
	public void testCountDaoStationnement() {
		IStationnementDAO dao = factory.getStationnementDAO();
		int c = dao.count();
		assertEquals(1,c);
	}

	
	/**
	 * Test une arrivee de voiture
	 * @throws ParkingException 
	 *
	 */
	@Test
	public void testArriveeVoit1Stationnement() throws Exception {
		IStationnementDAO dao = factory.getStationnementDAO();
		Stationnement s = dao.arriveeVoiture(pb.getImmatr(), "P02");
		assertEquals(s.getPersonne(), pb);
		assertEquals(s.getPlace(), "P02");
	}
	/**
	 * Test une arrivee de voiture
	 * @throws ParkingException 
	 *
	 */
	@Test
	public void testArriveeVoit2Stationnement() throws Exception {
		IStationnementDAO dao = factory.getStationnementDAO();
		Stationnement s = dao.arriveeVoiture(pb.getImmatr());
		assertEquals(s.getPersonne(), pb);
		assertEquals(s.getPlace(), "P02");
	}
	
	/**
	 * Test une sortie de voiture
	 * @throws ParkingException 
	 *
	 */
	@Test
	public void testInfoSortieVoitStationnement() throws Exception {
		IStationnementDAO dao = factory.getStationnementDAO();
		InfoSortieVoiture i = dao.sortieVoiture(pa.getImmatr());
		//System.out.println(i.getImmatr());
		//System.out.println(i.getPlace());
		//System.out.println(i.getMinutes());
		assertEquals(i.getImmatr(), pa.getImmatr());
		
	}

	/**
	 * Exécuté une fois et ceci avant tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@BeforeClass
	public void beforeClass() throws PersistanceException, FileNotFoundException {
		ConnexionSingleton.setInfoConnexion(
				new ConnexionFromFile("./resources/connexionParking_Test.properties", Databases.FIREBIRD));
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./resources/scriptInitDBTest.sql");
		factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, ConnexionSingleton.getConnexion());
	}

	/**
	 * Exécuté une fois et ceci après tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@AfterClass
	public void afterClass() throws FileNotFoundException, PersistanceException {
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./resources/scriptInitDBTest.sql");
		ConnexionSingleton.liberationConnexion();
	}

}
