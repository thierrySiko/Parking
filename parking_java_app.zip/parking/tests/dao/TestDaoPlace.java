package dao;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Optional;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dao.DAOFactory.TypePersistance;
import database.connexion.ConnexionFromFile;
import database.connexion.ConnexionSingleton;
import database.connexion.PersistanceException;
import database.uri.Databases;
import model.Place;
import utils.DatabaseUtil;

public class TestDaoPlace {
	private DAOFactory factory;

	private final Place pa = new Place("P01", 10, true);
	private final Place pb = new Place("P02", 10, true); 

	/**
	 * Test un getFromCode
	 */
	@Test
	public void testGetDaoPlace() {
		IPlaceDAO dao = factory.getPlaceDAO();
		Optional<Place> p = dao.getFromID(pa.getCode());
		// Vérifie si l'objet existe
		assertTrue(p.isPresent());
		assertEquals(p.get(), pa);
		// teste une autre place 
		p = dao.getFromID(pb.getCode());
		assertTrue(p.isPresent());
		assertEquals(p.get(), pb);
	}

	/**
	 * Teste un getListe
	 */
	@Test
	public void testGetListeDaoPlace() {
		IPlaceDAO dao = factory.getPlaceDAO();
		List<Place> l = dao.getListe(null);
		assertEquals(l.size(), 5);
		// Vérifie si pa existe dans la liste
		assertEquals(l.get(0), pa);
	}

	/**
	 * Test l'ajout et la suppression
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetInsertDeleteDaoPlace() throws Exception {
		IPlaceDAO dao = factory.getPlaceDAO();
		// Un nouvelle place
		Place pn = new Place("P06",10, true);
		String code = dao.insert(pn).getCode();
		// vérifie si le code renvoyé est le bon
		assertEquals(code, pn.getCode());
		// vérifie que l'on récupére bien la même place
		Optional<Place> p = dao.getFromID(code);
		assertTrue(p.isPresent());
		assertEquals(p.get(), pn);
		// Test Supression
		assertTrue(dao.delete(pn));
		// Verifie qu'il n'existe plus
		p = dao.getFromID(code);
		assertFalse(p.isPresent());
	}

	@Test
	public void testInsertUpdateDelete() throws Exception {
		IPlaceDAO dao = factory.getPlaceDAO();
		// Un nouvelle place
		Place pNew = new Place("P06",10,true); 
		Place pModif = new Place("P06",15, true); 
		String code = dao.insert(pNew).getCode();
		// vérifie que l'on récupére bien la même place
		Optional<Place> p = dao.getFromID(code);
		assertTrue(p.isPresent());
		assertEquals(p.get(), pNew);
		// Modification
		boolean res = dao.update(pModif);
		// test ok
		assertTrue(res);
		// récupère l'objet pour voir si changement ok
		Optional<Place> pRetour = dao.getFromID(pModif.getCode());
		assertTrue(pRetour.isPresent());
		assertEquals(pModif, pRetour.get());
		// Annule l'enregistrement pour revenir au même point de départ
		assertTrue(dao.delete(pRetour.get()));

	}

	// Insertion avec Exception attendue
	@Test(expectedExceptions = ParkingPKException.class)
	public void testBadPKInsert() throws Exception {
		IPlaceDAO dao = factory.getPlaceDAO();
		// Un nouvelle place
		Place pn = new Place("P01",5, true);
		dao.insert(pn).getCode();
	}

	// Insertion avec Exception attendue
	/*@Test(expectedExceptions = ParkingConstraintException.class)
	public void testPasDeTailleInsert() throws Exception {
		IPlaceDAO dao = factory.getPlaceDAO();
		// Un nouvelle place
		Place pn = new Place("P07",null, true);
		dao.insert(pn).getCode();
	}*/

	/**
	 * Exécuté une fois et ceci avant tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@BeforeClass
	public void beforeClass() throws PersistanceException, FileNotFoundException {
		ConnexionSingleton.setInfoConnexion(
				new ConnexionFromFile("./resources/connexionParking_Test.properties", Databases.FIREBIRD));
		// Réinitialise la base de données dans son état initial
		// DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./resources/scriptInitDBTest.sql");
		factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, ConnexionSingleton.getConnexion());
	}

	/**
	 * Exécuté une fois et ceci après tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@AfterClass
	public void afterClass() throws FileNotFoundException, PersistanceException {
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./resources/scriptInitDBTest.sql");
		ConnexionSingleton.liberationConnexion();
	}

}
