package exemple;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import database.connexion.ConnexionH2MemTest;
import database.connexion.ConnexionSingleton;
import database.connexion.PersistanceException;
import utils.DatabaseUtil;

public class Test_H2DB_MEM {
	private Connection connexion;

	@Test
	public void connectionOK() throws SQLException {
		assertNotNull(connexion);
		Statement q = connexion.createStatement();
		int cpt = 0;
		// Exécution du query
		boolean res = q.execute("select * from Tbrol");
		if (res) {
			// Récupère le RS
			ResultSet rs = q.getResultSet();

			while (rs.next()) {
				cpt++;
			}
			assertEquals(cpt, 5);

			connexion.commit();
			q.close();

		} else
			fail();
	}

	@Test
	public void testBiResultSetUpdate() {
		try (Statement q07 = connexion.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);) {
			q07.execute("SELECT * FROM TBROL");
			ResultSet rs = q07.getResultSet();

			rs.absolute(3);
			String n = rs.getString(2);
			rs.updateString(2, n + "_1");
			rs.updateRow();
			rs.absolute(1);
			rs.absolute(3);
			String r = rs.getString(2);
			assertEquals(n + "_1", r);

			// Vérifie si elle existe dans le ResultSet
		} catch (SQLException e) {
			fail();
		}
	}

	@Test
	public void testBiResultSetInsert() {
		try (Statement q07 = connexion.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);) {
			q07.execute("SELECT * FROM TBROL");
			ResultSet rs = q07.getResultSet();
			rs.last();
			rs.moveToInsertRow();
			rs.updateString(2, "HELLO1");
			rs.insertRow();
			rs.moveToInsertRow();
			rs.updateString(2, "HELLO2");
			rs.insertRow();
			q07.getConnection().commit();
		} catch (SQLException e) {
			fail();
		}
		try (Statement q07 = connexion.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);) {
			q07.execute("SELECT * FROM TBROL");
			ResultSet rs = q07.getResultSet();
			rs.last();
			int nb=rs.getRow();
			assertTrue(nb==7);
		} catch (SQLException e) {
			fail();
		}
		
	}

	@BeforeClass
	public void beforeClass() throws PersistanceException, FileNotFoundException, SQLException {
		ConnexionSingleton.setInfoConnexion(new ConnexionH2MemTest());
		connexion = ConnexionSingleton.getConnexion();

		// Création des tables
		DatabaseUtil.executeScriptSQL(connexion, "./resources/table_H2Test.sql");

	}

	@AfterClass
	public void afterClass() {
		ConnexionSingleton.liberationConnexion();
	}

}
