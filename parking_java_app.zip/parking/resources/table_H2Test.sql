Create table Tbrol( id identity not null primary key, nom varchar(30));
insert into tbrol(nom) values('TEST1');
insert into tbrol(nom) values('TEST2');
insert into tbrol(nom) values('TEST3');
insert into tbrol(nom) values('TEST4');
insert into tbrol(nom) values('TEST5');