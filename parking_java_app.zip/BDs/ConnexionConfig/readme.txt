Les fichiers connexion_*.properties doivent �tre copi�s (ou recr��s) dans le dossier "resources" du projet.
Ces fichiers devront �tre adapt�s � l'endroit o� vous allez mettre les bases de donn�es.
Ces fichiers ne seront pas rajout�s au d�p�t GIT!
Ainsi vous pouvez adapter les chemins � votre guise en fonction de votre OS et vos pr�f�rences.
Pour ma part je les sauve dans "c:/DBS/pdb/

