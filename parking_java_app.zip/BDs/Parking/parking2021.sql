/********************* ROLES **********************/

/********************* UDFS ***********************/

/********************* FUNCTIONS ***********************/

/****************** SEQUENCES ********************/

/******************** DOMAINS *********************/

CREATE DOMAIN DNOM
 AS VARCHAR(30)
 check( trim(value)<>'')
 COLLATE FR_FR;
 
CREATE DOMAIN DPLACE
 AS CHAR(3)
 check (value similar to '[A-Z][0-9]{2}' )
 COLLATE ISO8859_1;
 
CREATE DOMAIN DTAILLEPLACE
 AS SMALLINT
 check (value>0)
;

/******************** TABLES **********************/

CREATE TABLE THISTORIQUE
(
  FKPERSONNE_HIS CHAR(10) NOT NULL,
  MOMENTA_HIS TIMESTAMP NOT NULL,
  FKPLACE_HIS DPLACE,
  MOMENTS_HIS TIMESTAMP DEFAULT current_timestamp NOT NULL,
  PRIMARY KEY (FKPERSONNE_HIS,MOMENTA_HIS)
);

CREATE TABLE TPERSONNEL
(
  IMMATR_PER CHAR(10) NOT NULL,
  NOM_PER DNOM NOT NULL,
  PRENOM_PER DNOM,
  EMAIL_PER VARCHAR(40),
  PRIMARY KEY (IMMATR_PER)
);

CREATE TABLE TPLACE
(
  CODE_PLA DPLACE NOT NULL,
  TAILLE_PLA DTAILLEPLACE,
  LIBRE_PLA BOOLEAN DEFAULT TRUE NOT NULL,
  PRIMARY KEY (CODE_PLA)
);

CREATE TABLE TSTATIONNEMENT
(
  FKPERSONNE_STA CHAR(10) NOT NULL,
  FKPLACE_STA DPLACE NOT NULL,
  MOMENTA_STA TIMESTAMP DEFAULT current_timestamp NOT NULL,
  PRIMARY KEY (FKPERSONNE_STA),
  UNIQUE (FKPLACE_STA)
);

/******************* EXCEPTIONS *******************/

CREATE EXCEPTION EXC_PARKING
'Place @1 non disponible';
/******************** TRIGGERS ********************/

SET TERM ^ ;
CREATE TRIGGER TRG_ARRIVEEVOIT FOR TSTATIONNEMENT ACTIVE
BEFORE INSERT 

AS 
declare libre type of COLUMN TPlace.LIBRE_PLA;
BEGIN 
 libre=(select p.LIBRE_PLA from TPlace p where p.CODE_PLA=new.FKPLACE_STA);
 if(not libre) then EXCEPTION exc_parking using (new.FKPLACE_STA);
 update TPlace p set p.LIBRE_PLA=FALSE where p.CODE_PLA = new.FKPLACE_STA;
END^

CREATE TRIGGER TRG_SORTIEVOIT FOR TSTATIONNEMENT ACTIVE
AFTER DELETE 
AS 
BEGIN 
 Update TPLACE set Libre_Pla=TRUE where code_pla=old.FKPLACE_STA;
 Insert into THISTORIQUE  (FKPERSONNE_HIS,FKPLACE_HIS,MOMENTA_HIS)
        Values (old.FKPERSONNE_STA,old.FKPLACE_STA,old.MOMENTA_STA);
END^

CREATE PROCEDURE ARRIVEE_VOIT (
    IMMATR CHAR(10),
    PLACE TYPE OF DPLACE DEFAULT null )
RETURNS (
    PLACEG TYPE OF DPLACE,
    MA TIMESTAMP )
AS
Begin
 if (place is null ) then
 begin 
  select first 1 p.CODE_PLA from TPLACE p where p.LIBRE_PLA=TRUE into :place;
  if (place is null ) then exception EXC_PARKING 'Parking Plein';
 end
  MA=CURRENT_TIMESTAMP;
-- Insertion
 INSERT INTO TSTATIONNEMENT  VALUES (:immatr,:place,:MA);
-- maj variables de sortie
 placeG=place;
End^
 
CREATE PROCEDURE HISTORIQUE (
    IMMATR CHAR(10) )
RETURNS (
    MA TIMESTAMP,
    MS TIMESTAMP,
    DUREE INTEGER,
    PLACE TYPE OF DPLACE )

AS
BEGIN
for select h.MOMENTA_HIS,h.MOMENTS_HIS,h.FKPLACE_HIS,
          datediff(minute,h.MOMENTA_HIS,h.MOMENTS_HIS) from THISTORIQUE h
 where h.FKPERSONNE_HIS=:Immatr order by  h.MOMENTA_HIS desc
 into :MA,:MS,:place,:duree
 Do suspend;
end^

CREATE PROCEDURE SORTIE_VOIT (
    IMMATR CHAR(10) )
RETURNS (
    PLACE TYPE OF DPLACE,
    DUREE INTEGER )

AS
declare momentA timestamp;
begin
 delete from TSTATIONNEMENT s where s.FKPERSONNE_STA=:immatr
 returning s.FKPLACE_STA,s.MOMENTA_STA into :place,:momentA;
 
 duree=datediff(minute,momentA,current_timestamp);
end^
SET TERM ; ^

ALTER TABLE THISTORIQUE ADD 
  FOREIGN KEY (FKPERSONNE_HIS) REFERENCES TPERSONNEL (IMMATR_PER) ON UPDATE CASCADE;
ALTER TABLE THISTORIQUE ADD 
  FOREIGN KEY (FKPLACE_HIS) REFERENCES TPLACE (CODE_PLA) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE TSTATIONNEMENT ADD 
  FOREIGN KEY (FKPERSONNE_STA) REFERENCES TPERSONNEL (IMMATR_PER) ON UPDATE CASCADE;
ALTER TABLE TSTATIONNEMENT ADD 
  FOREIGN KEY (FKPLACE_STA) REFERENCES TPLACE (CODE_PLA) ON UPDATE CASCADE;
GRANT EXECUTE
 ON PROCEDURE ARRIVEE_VOIT TO  ETUDIANT WITH GRANT OPTION;

GRANT EXECUTE
 ON PROCEDURE HISTORIQUE TO  ETUDIANT WITH GRANT OPTION;

GRANT EXECUTE
 ON PROCEDURE SORTIE_VOIT TO  ETUDIANT WITH GRANT OPTION;

GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE
 ON THISTORIQUE TO  ETUDIANT WITH GRANT OPTION;

GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE
 ON TPERSONNEL TO  ETUDIANT WITH GRANT OPTION;

GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE
 ON TPLACE TO  ETUDIANT WITH GRANT OPTION;

GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE
 ON TSTATIONNEMENT TO  ETUDIANT WITH GRANT OPTION;
COMMIT

-- DONNEES
insert into TPlace(CODE_PLA,TAILLE_PLA) values( 'P01',10);
insert into TPlace(CODE_PLA,TAILLE_PLA) values( 'P02',10);
insert into TPlace(CODE_PLA,TAILLE_PLA) values( 'P03',5);
insert into TPlace(CODE_PLA,TAILLE_PLA) values( 'P04',5);
insert into TPlace(CODE_PLA,TAILLE_PLA,LIBRE_PLA) values( 'P05',10,false);

Insert into TPersonnel values('AAA-111','de Block','Anne','deBlock.a@gmail.com');
Insert into TPersonnel values('BBB-222','De Bocher','Robert','deBocher.r@gmail.com');
Insert into TPersonnel values('CCC-333','Agenaes','Luc','Agenaes.l@gmail.fr');
Insert into TPersonnel values('DDD-444','Zotero','Jean','Zotero.j@hotmail.fr');
Commit
